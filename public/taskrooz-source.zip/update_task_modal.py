with open('src/components/TaskModal.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add calendarType from useTask()
content = content.replace(
    "    users,\n    setIsUpgradeModalOpen,",
    "    users,\n    setIsUpgradeModalOpen,\n    calendarType,"
)

# 2. Add reasonUncompleted state
target_state = "  const [isPinned, setIsPinned] = useState(false);"
replacement_state = """  const [isPinned, setIsPinned] = useState(false);
  const [reasonUncompleted, setReasonUncompleted] = useState<string | undefined>(undefined);"""
assert target_state in content
content = content.replace(target_state, replacement_state, 1)

# 3. Update useEffect
target_effect = "      setSubtasks(editingTask.subtasks || []);\n      setAssignedUserId(editingTask.userId || currentUser?.id || '');"
replacement_effect = """      setSubtasks(editingTask.subtasks || []);
      setAssignedUserId(editingTask.userId || currentUser?.id || '');
      setReasonUncompleted(editingTask.reasonUncompleted);"""
assert target_effect in content
content = content.replace(target_effect, replacement_effect, 1)

target_else = "      setSubtasks([]);\n      setAssignedUserId(currentUser?.id || '');"
replacement_else = """      setSubtasks([]);
      setAssignedUserId(currentUser?.id || '');
      setReasonUncompleted(undefined);"""
assert target_else in content
content = content.replace(target_else, replacement_else, 1)

# 4. Update updateTask in handleSubmit
target_update = """          isPinned,
          subtasks,
          ...(currentUser?.role === 'admin' ? { userId: assignedUserId } : {}),
        });"""
replacement_update = """          isPinned,
          subtasks,
          reasonUncompleted: reasonUncompleted || undefined,
          uncompletedCategory: reasonUncompleted ? editingTask.uncompletedCategory : undefined,
          ...(currentUser?.role === 'admin' ? { userId: assignedUserId } : {}),
        });"""
assert target_update in content
content = content.replace(target_update, replacement_update, 1)

# 5. Insert uncompleted reason card if editingTask has reason
target_modal_body = """        {/* Modal Scrollable Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">"""
replacement_modal_body = """        {/* Modal Scrollable Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          {editingTask && editingTask.reasonUncompleted && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-between text-xs">
              <div className="space-y-0.5 text-right">
                <div className="text-[11px] font-bold text-rose-700 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                  <span>ثبت شده با تیک قرمز (عدم انجام)</span>
                </div>
                <div className="font-extrabold text-rose-950">دلیل: {editingTask.reasonUncompleted}</div>
              </div>
              <button
                type="button"
                onClick={() => setReasonUncompleted(undefined)}
                className="px-2.5 py-1.5 rounded-xl bg-white text-rose-600 border border-rose-200 text-[10px] font-black hover:bg-rose-100 cursor-pointer shadow-xs"
              >
                پاک کردن تیک قرمز
              </button>
            </div>
          )}"""
assert target_modal_body in content
content = content.replace(target_modal_body, replacement_modal_body, 1)

with open('src/components/TaskModal.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('TaskModal.tsx updated successfully!')
