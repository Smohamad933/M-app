with open('src/components/MainLayout.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

target = """              {/* Interface Mode Toggle in Mobile Drawer */}
              <div className="p-1 bg-slate-100 rounded-xl border border-slate-200/80 flex items-center gap-1 text-[11px] font-bold">"""

replacement = """              {/* Instagram Studio for Admin in Mobile Drawer */}
              {isAdmin && (
                <button
                  type="button"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    sounds.playPop();
                    if (onOpenInstagramStudio) {
                      onOpenInstagramStudio();
                    } else {
                      const url = new URL(window.location.href);
                      url.searchParams.set('page', 'instagram');
                      window.location.href = url.toString();
                    }
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-pink-700 bg-pink-50 border border-pink-200 font-bold text-xs transition-colors cursor-pointer"
                >
                  <span className="text-xs">📸</span>
                  <span>استودیو اسلایدهای اینستاگرام</span>
                </button>
              )}

              {/* Theme & Calendar Quick Switcher in Mobile Drawer */}
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={toggleThemeMode}
                  className="py-1.5 px-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-1.5 border border-slate-200/80 cursor-pointer"
                >
                  {themeMode === 'dark' ? <Sun className="w-3.5 h-3.5 text-amber-500" /> : <Moon className="w-3.5 h-3.5 text-slate-700" />}
                  <span>{themeMode === 'dark' ? 'تم روشن' : 'تم دارک'}</span>
                </button>

                <button
                  type="button"
                  onClick={toggleCalendarType}
                  className="py-1.5 px-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-1.5 border border-slate-200/80 cursor-pointer"
                >
                  <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{calendarType === 'jalali' ? 'شمسی' : 'میلادی'}</span>
                </button>
              </div>

              {/* Interface Mode Toggle in Mobile Drawer */}
              <div className="p-1 bg-slate-100 rounded-xl border border-slate-200/80 flex items-center gap-1 text-[11px] font-bold">"""

assert target in content
content = content.replace(target, replacement, 1)

with open('src/components/MainLayout.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('MainLayout drawer updated!')
