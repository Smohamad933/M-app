with open('src/components/MainLayout.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

target = """            {/* TAB 1: DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6 animate-in fade-in w-full min-w-0">"""

replacement = """            {/* TAB 1: DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6 animate-in fade-in w-full min-w-0">
                {/* Simple Mode Friendly Quick Actions Card */}
                {interfaceMode === 'simple' && (
                  <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in">
                    <div className="space-y-1 text-right">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-lg bg-emerald-600 text-white font-bold text-[11px]">🌿 کاربری آسان</span>
                        <h2 className="text-sm font-black text-slate-900">امروز می‌خواهید چه کاری انجام دهید؟</h2>
                      </div>
                      <p className="text-xs text-slate-600">
                        سامانه در حالت آسان و بدون پیچیدگی است. تسک جدید بنویسید یا زمان‌سنج تمرکز را استارت بزنید:
                      </p>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        onClick={() => openCreateModal(selectedDate)}
                        className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>ثبت سریع تسک</span>
                      </button>

                      <button
                        onClick={() => setActiveTab('focus')}
                        className="px-4 py-2.5 rounded-2xl bg-slate-900 hover:bg-black text-white font-black text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Timer className="w-4 h-4 text-emerald-400" />
                        <span>شروع تمرکز</span>
                      </button>
                    </div>
                  </div>
                )}"""

assert target in content
content = content.replace(target, replacement, 1)

with open('src/components/MainLayout.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('MainLayout simple mode banner added!')
