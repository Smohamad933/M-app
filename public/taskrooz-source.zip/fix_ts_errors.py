# 1. Fix server/apiHandler.ts line 771 duplicate isTestRunner
with open('server/apiHandler.ts', 'r', encoding='utf-8') as f:
    text = f.read()

# Replace second `const isTestRunner`
pos1 = text.find('const isTestRunner = req.headers')
assert pos1 != -1
pos2 = text.find('const isTestRunner = req.headers', pos1 + 1)
if pos2 != -1:
    text = text[:pos2] + '// isTestRunner already defined above' + text[pos2 + len('const isTestRunner = req.headers[\'x-test-suite\'] === \'true\' || Boolean(body.skipVerificationForTest);'):]

with open('server/apiHandler.ts', 'w', encoding='utf-8') as f:
    f.write(text)
print("server/apiHandler.ts fixed!")

# 2. Fix TaskCard.tsx
with open('src/components/TaskCard.tsx', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace(
    "import { formatPersianDate, formatAppDate, toPersianDigits } from '../utils/persianDate';",
    "import { formatAppDate, toPersianDigits } from '../utils/persianDate';"
)
text = text.replace(
    "import { formatPersianDate, toPersianDigits } from '../utils/persianDate';",
    "import { formatAppDate, toPersianDigits } from '../utils/persianDate';"
)

text = text.replace(
    "    togglePin,\n    addFocusMinutes,\n    calendarType,",
    "    togglePin,\n    addFocusMinutes,\n    calendarType,\n    updateTask,"
)

with open('src/components/TaskCard.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("TaskCard.tsx fixed!")

# 3. Fix TaskModal.tsx
with open('src/components/TaskModal.tsx', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace(
    "import { formatPersianDate, formatAppDate, toPersianDigits, isoToJalali, jalaliToISO, PERSIAN_MONTHS, getTodayISO } from '../utils/persianDate';",
    "import { formatAppDate, toPersianDigits, isoToJalali, jalaliToISO, PERSIAN_MONTHS, getTodayISO } from '../utils/persianDate';"
)
text = text.replace(
    "import { formatPersianDate, toPersianDigits, isoToJalali, jalaliToISO, PERSIAN_MONTHS, getTodayISO } from '../utils/persianDate';",
    "import { formatAppDate, toPersianDigits, isoToJalali, jalaliToISO, PERSIAN_MONTHS, getTodayISO } from '../utils/persianDate';"
)

with open('src/components/TaskModal.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("TaskModal.tsx fixed!")

# 4. Fix ProfileModal.tsx
with open('src/components/ProfileModal.tsx', 'r', encoding='utf-8') as f:
    text = f.read()

target = "    updateMyProfile,\n    isPro,\n    setIsUpgradeModalOpen,"
replacement = "    updateMyProfile,\n    isPro,\n    setIsUpgradeModalOpen,\n    themeMode,\n    setThemeMode,\n    calendarType,\n    setCalendarType,\n    interfaceMode,\n    setInterfaceMode,"
if target in text:
    text = text.replace(target, replacement, 1)

with open('src/components/ProfileModal.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("ProfileModal.tsx fixed!")

# 5. Fix UserManagementView.tsx Sun, Moon, Calendar imports
with open('src/components/UserManagementView.tsx', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace(
    "  CheckCircle2,\n  Sliders,\n} from 'lucide-react';",
    "  CheckCircle2,\n  Sliders,\n  Sun,\n  Moon,\n  Calendar,\n} from 'lucide-react';"
)
if "Sun," not in text:
    text = text.replace(
        "  CheckCircle2,\n  Sliders,",
        "  CheckCircle2,\n  Sliders,\n  Sun,\n  Moon,\n  Calendar,"
    )

with open('src/components/UserManagementView.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("UserManagementView.tsx fixed!")

# 6. Fix CalendarView.tsx
with open('src/components/CalendarView.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("  formatPersianDate,\n", "")
with open('src/components/CalendarView.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("CalendarView.tsx fixed!")

# 7. Fix HourlyPlannerView.tsx
with open('src/components/HourlyPlannerView.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("  formatPersianDate,\n", "")
with open('src/components/HourlyPlannerView.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("HourlyPlannerView.tsx fixed!")

# 8. Fix WeeklyStrip.tsx
with open('src/components/WeeklyStrip.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("formatPersianDate, ", "")
with open('src/components/WeeklyStrip.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("WeeklyStrip.tsx fixed!")

# 9. Fix Header.tsx
with open('src/components/Header.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("formatPersianDate, ", "")
text = text.replace("  Zap,\n", "")
text = text.replace("interfaceMode, toggleInterfaceMode,", "")
with open('src/components/Header.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("Header.tsx fixed!")

# 10. Fix FocusTimer.tsx
with open('src/components/FocusTimer.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("  Sparkles,\n", "")
text = text.replace("  CheckCircle2,\n", "")
text = text.replace("  TrendingUp,\n", "")
text = text.replace("    themeMode,\n", "")
text = text.replace("  const [showTimeAdjuster, setShowTimeAdjuster] = useState(false);\n", "")
with open('src/components/FocusTimer.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("FocusTimer.tsx fixed!")

# 11. Fix GroupFocusRoom.tsx
with open('src/components/GroupFocusRoom.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("  const [isLobbyQrModalOpen, setIsLobbyQrModalOpen] = useState(false);\n", "")
with open('src/components/GroupFocusRoom.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("GroupFocusRoom.tsx fixed!")

# 12. Fix InstagramSlidesStudio.tsx
with open('src/components/InstagramSlidesStudio.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("renderFeatureMockupCard = (cycleIdx: number, isLight: boolean) =>", "renderFeatureMockupCard = (cycleIdx: number, _isLight: boolean) =>")
with open('src/components/InstagramSlidesStudio.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("InstagramSlidesStudio.tsx fixed!")
