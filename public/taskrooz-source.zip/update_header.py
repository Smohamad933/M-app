with open('src/components/Header.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update imports
content = content.replace(
    "import { getGreeting, formatPersianDate, toPersianDigits, getTodayISO } from '../utils/persianDate';",
    "import { getGreeting, formatPersianDate, formatAppDate, toPersianDigits, getTodayISO } from '../utils/persianDate';"
)

content = content.replace(
    "  CheckCircle2,\n  Search,\n} from 'lucide-react';",
    "  CheckCircle2,\n  Search,\n  Sun,\n  Moon,\n  Calendar,\n  Zap,\n} from 'lucide-react';"
)

# 2. Add useTask destructuring
content = content.replace(
    "  const { tasks, streak, selectedDate, setIsShareModalOpen } = useTask();",
    "  const { tasks, streak, selectedDate, setIsShareModalOpen, calendarType, toggleCalendarType, themeMode, toggleThemeMode, interfaceMode, toggleInterfaceMode } = useTask();"
)

# 3. Add Quick Action Buttons
old_quick_actions = """        {/* Quick action buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onToggleSearch}"""

new_quick_actions = """        {/* Quick action buttons */}
        <div className="flex items-center gap-1.5">
          {/* Dark / Light Toggle */}
          <button
            type="button"
            onClick={toggleThemeMode}
            className="p-2 rounded-xl text-slate-600 dark:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer"
            title={themeMode === 'dark' ? 'تغییر به تم روشن' : 'تغییر به تم دارک'}
          >
            {themeMode === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Calendar Type Toggle */}
          <button
            type="button"
            onClick={toggleCalendarType}
            className="px-2.5 py-1 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer flex items-center gap-1 border border-slate-200 dark:border-slate-700"
            title={calendarType === 'jalali' ? 'تغییر به تقویم میلادی' : 'تغییر به تقویم شمسی'}
          >
            <Calendar className="w-3 h-3 text-indigo-500" />
            <span>{calendarType === 'jalali' ? 'شمسی' : 'میلادی'}</span>
          </button>

          <button
            onClick={onToggleSearch}"""

assert old_quick_actions in content
content = content.replace(old_quick_actions, new_quick_actions, 1)

# 4. Format date with calendarType
content = content.replace(
    "{formatPersianDate(selectedDate, 'full')}",
    "{formatAppDate(selectedDate, calendarType, 'full')}"
)

# 5. Header dark styles
content = content.replace(
    "header className=\"px-5 pt-4 pb-3 bg-white/90 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-20\"",
    "header className=\"px-5 pt-4 pb-3 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 sticky top-0 z-20\""
)

with open('src/components/Header.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('Header.tsx updated!')
