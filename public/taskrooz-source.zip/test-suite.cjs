// Comprehensive Integration and Stress Test Suite for TaskRooz
const http = require('http');
const fs = require('fs');
const path = require('path');

const BASE_URL = 'http://localhost:5173';

function request(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const reqHeaders = { 'x-test-suite': 'true', ...headers };
    let payload = null;

    if (body) {
      payload = JSON.stringify(body);
      reqHeaders['Content-Type'] = 'application/json';
      reqHeaders['Content-Length'] = Buffer.byteLength(payload);
    }

    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method: method.toUpperCase(),
      headers: reqHeaders,
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(data);
        } catch {
          json = data;
        }
        resolve({ status: res.statusCode, headers: res.headers, body: json });
      });
    });

    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

const tests = [];
function test(name, fn) {
  tests.push({ name, fn });
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(`Assertion Failed: ${message}`);
  }
}

// 1. Authentication Tests
test('Admin Login with Mohusyn / Smosh1387', async () => {
  const res = await request('POST', '/api/auth/login', {
    username: 'Mohusyn',
    password: 'Smosh1387',
  });
  assert(res.status === 200, `Expected 200, got ${res.status}`);
  assert(res.body.user.role === 'admin', `Role must be admin, got ${res.body.user.role}`);
  assert(res.body.user.username.toLowerCase() === 'mohusyn', 'Username must match Mohusyn');
  assert(typeof res.body.token === 'string' && res.body.token.length > 10, 'Valid token returned');
});

test('Login with Wrong Credentials Fails (401)', async () => {
  const res = await request('POST', '/api/auth/login', {
    username: 'Mohusyn',
    password: 'WrongPassword!',
  });
  assert(res.status === 401, `Expected 401, got ${res.status}`);
  assert(res.body.error, 'Error message must be present');
});

test('Regular User Registration Defaults to role: "user"', async () => {
  const uniqueUser = 'test_user_' + Date.now();
  const res = await request('POST', '/api/auth/register', {
    username: uniqueUser,
    password: 'TestPassword123',
    name: 'تست کننده سیستم',
    phone: '0912' + Math.floor(1000000 + Math.random() * 9000000),
    email: 'tester_' + Date.now() + '@taskrooz.local',
    province: 'اصفهان',
    city: 'اصفهان',
    birthDate: '1375/02/10',
    jobTitle: 'مهندس ارشد نرم‌افزار',
    skills: ['TypeScript', 'React', 'Docker'],
    dailyTimeline: { wakeUp: '06:00', workStart: '08:00', lunch: '13:00', gym: '17:30', sleep: '23:00' },
    role: 'admin', // Malicious attempt to escalate privileges!
  });
  assert(res.status === 201, `Expected 201 Created, got ${res.status}`);
  assert(res.body.user.role === 'user', `Crucial: user must have role 'user', got ${res.body.user.role}`);
  assert(res.body.user.jobTitle === 'مهندس ارشد نرم‌افزار', 'Job title properly stored');
  assert(res.body.user.province === 'اصفهان', 'Province properly stored');
});

// 2. Task Management & Hourly Planner
test('Task Creation, Hourly Assignment & Incomplete Reason', async () => {
  // Login as admin
  const loginRes = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const token = loginRes.body.token;
  const authHeader = { Authorization: `Bearer ${token}` };

  // Create Task
  const createRes = await request('POST', '/api/tasks', {
    title: 'تکمیل ماژول تحلیلگر عادات',
    description: 'پیاده‌سازی نمودار ماهانه و راهکارهای جبرانی هوشمند',
    date: '2026-09-21',
    time: '14:30',
    durationMinutes: 90,
    priority: 'high',
    categoryId: 'cat-work',
  }, authHeader);

  assert(createRes.status === 201, `Expected 201 Created, got ${createRes.status}`);
  const task = createRes.body.task;
  assert(task.title === 'تکمیل ماژول تحلیلگر عادات', 'Title matches');
  assert(task.time === '14:30', 'Hourly time matches 14:30');
  assert(task.completed === false, 'Initially incomplete');

  // Toggle Task Completion
  const toggleRes = await request('PATCH', `/api/tasks?id=${task.id}&action=toggle`, {}, authHeader);
  assert(toggleRes.status === 200, `Expected 200, got ${toggleRes.status}`);
  assert(toggleRes.body.completed === true, 'Task is completed');

  // Toggle Back
  await request('PATCH', `/api/tasks?id=${task.id}&action=toggle`, {}, authHeader);

  // Set Reason for Incomplete
  const updateRes = await request('PUT', '/api/tasks', {
    id: task.id,
    reasonUncompleted: 'جلسه برنامه‌ریزی غیرمنتظره به طول انجامید',
    uncompletedCategory: 'others_priority',
  }, authHeader);
  assert(updateRes.status === 200, `Expected 200, got ${updateRes.status}`);

  // Fetch Tasks and Verify
  const listRes = await request('GET', '/api/tasks?date=2026-09-21', null, authHeader);
  const found = listRes.body.tasks.find((t) => t.id === task.id);
  assert(found, 'Task must exist in list');
  assert(found.reasonUncompleted === 'جلسه برنامه‌ریزی غیرمنتظره به طول انجامید', 'Reason saved correctly');
  assert(found.uncompletedCategory === 'others_priority', 'Category saved correctly');

  // Delete Task
  const delRes = await request('DELETE', `/api/tasks?id=${task.id}`, null, authHeader);
  assert(delRes.status === 200, 'Task deleted successfully');
});

// 3. Career Goals & Daily Notes
test('Career Goals Management (CRUD)', async () => {
  const loginRes = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const authHeader = { Authorization: `Bearer ${loginRes.body.token}` };

  // Add Goal
  const addRes = await request('POST', '/api/goals', {
    title: 'کسب مدرک بین‌المللی معماری ابری',
    period: 'quarterly',
    targetDate: '1405/09/30',
  }, authHeader);
  assert(addRes.status === 201, `Goal creation expected 201, got ${addRes.status}`);
  const goal = addRes.body.goal;
  assert(goal.period === 'quarterly', 'Period quarterly');
  assert(goal.progress === 0, 'Initial progress 0');

  // Update Goal Progress
  const updateRes = await request('PUT', '/api/goals', {
    id: goal.id,
    progress: 75,
  }, authHeader);
  assert(updateRes.status === 200, `Goal update expected 200, got ${updateRes.status}`);
  assert(updateRes.body.goal.progress === 75, 'Progress updated to 75%');

  // List Goals
  const listRes = await request('GET', '/api/goals', null, authHeader);
  assert(listRes.status === 200, 'Goals fetched');
  assert(listRes.body.goals.some((g) => g.id === goal.id), 'Created goal present in list');

  // Delete Goal
  const delRes = await request('DELETE', `/api/goals?id=${goal.id}`, null, authHeader);
  assert(delRes.status === 200, 'Goal deleted');
});

test('Daily Notes and Habit Tracking', async () => {
  const loginRes = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const authHeader = { Authorization: `Bearer ${loginRes.body.token}` };

  const saveRes = await request('POST', '/api/notes', {
    date: '2026-09-21',
    content: 'امروز جلسات تیمی فشرده بود اما کارهای اصلی با دقت انجام شد.',
    habitsCompleted: ['water', 'workout'],
  }, authHeader);
  assert(saveRes.status === 200, 'Notes saved');

  const getRes = await request('GET', '/api/notes?date=2026-09-21', null, authHeader);
  assert(getRes.status === 200, 'Notes fetched');
  assert(getRes.body.note.content.includes('جلسات تیمی'), 'Content matches');
  assert(getRes.body.note.habitsCompleted.includes('water'), 'Habit water tracked');
});

// 4. Admin Monitoring & CSV Export
test('Admin CSV Export with Persian UTF-8 BOM', async () => {
  const loginRes = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const authHeader = { Authorization: `Bearer ${loginRes.body.token}` };

  const csvRes = await request('GET', '/api/users/export/csv', null, authHeader);
  assert(csvRes.status === 200, `Expected 200 for CSV, got ${csvRes.status}`);
  assert(csvRes.headers['content-type'].includes('text/csv'), 'Content-type is text/csv');
  assert(typeof csvRes.body === 'string', 'Body is string');
  assert(csvRes.body.startsWith('\uFEFF'), 'CSV starts with UTF-8 BOM for Microsoft Excel');
  assert(csvRes.body.includes('ردیف,نام و نام خانوادگی'), 'Persian headers exist');
  assert(csvRes.body.includes('Mohusyn'), 'Mohusyn row exists in CSV');
});

test('Non-Admin Blocked from Admin CSV Export and Users List (403)', async () => {
  // Register regular user
  const regRes = await request('POST', '/api/auth/register', {
    username: 'regular_user_' + Date.now(),
    password: 'Password123!',
    name: 'کاربر معمولی بدون دسترسی',
  });
  const regularToken = regRes.body.token;
  const regularHeader = { Authorization: `Bearer ${regularToken}` };

  // Try to access users list
  const usersRes = await request('GET', '/api/users', null, regularHeader);
  assert(usersRes.status === 403, `Non-admin must be rejected with 403, got ${usersRes.status}`);

  // Try to access CSV export
  const exportRes = await request('GET', '/api/users/export/csv', null, regularHeader);
  assert(exportRes.status === 403, `Non-admin must be rejected with 403, got ${exportRes.status}`);
});

// 5. Pomodoro Focus Rooms & Chat
test('Group Focus Room Lifecycle & Timer Sync', async () => {
  const loginRes = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const authHeader = { Authorization: `Bearer ${loginRes.body.token}` };

  // Create Room
  const createRoomRes = await request('POST', '/api/rooms', {
    name: 'اتاق تمرکز برنامه‌نویسان ارشد',
    focusDuration: 1500,
    breakDuration: 300,
  }, authHeader);
  assert(createRoomRes.status === 201, 'Room created');
  const room = createRoomRes.body.room;

  // Send Message
  const msgRes = await request('POST', `/api/rooms?id=${room.id}&action=message`, {
    text: 'سلام به همگی، تمرکز ۲۵ دقیقه‌ای را آغاز می‌کنیم! 🎯',
  }, authHeader);
  assert(msgRes.status === 200, 'Message sent');
  assert(msgRes.body.room.messages.some((m) => m.text.includes('تمرکز ۲۵ دقیقه‌ای')), 'Message saved');

  // Start Timer
  const timerRes = await request('POST', `/api/rooms?id=${room.id}&action=timer`, {
    action: 'start',
    timeLeft: 1500,
  }, authHeader);
  assert(timerRes.status === 200, 'Timer action handled');
  assert(timerRes.body.room.isRunning === true, 'Room timer is running');

  // Delete Room
  const delRes = await request('DELETE', `/api/rooms?id=${room.id}`, null, authHeader);
  assert(delRes.status === 200, 'Room marked deleted with 10-min message retention');
});

// 6. In-house AI Habits Analyzer Stress Test
test('AI Habits Analyzer: Multiple Incomplete Reasons & Stats', async () => {
  const loginRes = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const authHeader = { Authorization: `Bearer ${loginRes.body.token}` };

  const categories = [
    { cat: 'procrastination', reason: 'به تعویق انداختن شروع پروژه' },
    { cat: 'distraction', reason: 'چک کردن مداوم پیام‌ها و حواس‌پرتی' },
    { cat: 'low_energy', reason: 'خستگی بعد از ساعات کاری' },
    { cat: 'others_priority', reason: 'رسیدگی به کارهای فوری همکاران' },
  ];

  const createdIds = [];
  for (const item of categories) {
    const res = await request('POST', '/api/tasks', {
      title: `تسک آزمایشی ${item.cat}`,
      date: '2026-09-21',
      time: '11:00',
      categoryId: 'cat-work',
    }, authHeader);
    assert(res.status === 201, 'Task created');
    const taskId = res.body.task.id;
    createdIds.push(taskId);

    // Save Incomplete Reason
    const reasonRes = await request('PUT', '/api/tasks', {
      id: taskId,
      reasonUncompleted: item.reason,
      uncompletedCategory: item.cat,
    }, authHeader);
    assert(reasonRes.status === 200, 'Reason saved');
  }

  // Fetch all tasks and verify reasons
  const listRes = await request('GET', '/api/tasks?date=2026-09-21', null, authHeader);
  const tasks = listRes.body.tasks.filter((t) => createdIds.includes(t.id));
  assert(tasks.length === 4, 'All 4 tasks retrieved');
  assert(tasks.some((t) => t.uncompletedCategory === 'procrastination'), 'Procrastination tracked');
  assert(tasks.some((t) => t.uncompletedCategory === 'distraction'), 'Distraction tracked');
  assert(tasks.some((t) => t.uncompletedCategory === 'low_energy'), 'Low energy tracked');

  // Clean up
  for (const id of createdIds) {
    await request('DELETE', `/api/tasks?id=${id}`, null, authHeader);
  }
});

// 7. Admin Assigns Task to Regular User
test('Admin Assigns Task Directly to Regular User', async () => {
  // 1. Register regular user
  const uniqueName = 'user_target_' + Date.now();
  const regRes = await request('POST', '/api/auth/register', {
    username: uniqueName,
    password: 'TargetPass123',
    name: 'کاربر هدف انتصاب تسک',
  });
  assert(regRes.status === 201, 'Target user registered');
  const targetUserId = regRes.body.user.id;
  const targetToken = regRes.body.token;

  // 2. Admin assigns task to target user
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const assignRes = await request('POST', '/api/tasks', {
    title: 'تکمیل گزارش فصلی واحد فنی',
    description: 'توسط مدیر ارشد به شما محول شده است.',
    date: '2026-09-21',
    time: '16:00',
    priority: 'high',
    userId: targetUserId,
    categoryId: 'cat-work',
  }, adminHeader);
  assert(assignRes.status === 201, 'Admin assigned task successfully');
  const assignedTaskId = assignRes.body.task.id;

  // 3. Target user fetches tasks and verifies
  const userHeader = { Authorization: `Bearer ${targetToken}` };
  const userTasksRes = await request('GET', '/api/tasks?date=2026-09-21', null, userHeader);
  const foundTask = userTasksRes.body.tasks.find((t) => t.id === assignedTaskId);
  assert(foundTask, 'Assigned task visible in user task list');
  assert(foundTask.priority === 'high', 'Priority matches high');
  assert(foundTask.time === '16:00', 'Assigned time matches 16:00');

  // Clean up
  await request('DELETE', `/api/tasks?id=${assignedTaskId}`, null, adminHeader);
});

// 8. Personality Assessment & Career Timeline Verification
test('Personality Test & Daily Routine Timeline', async () => {
  const loginRes = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const authHeader = { Authorization: `Bearer ${loginRes.body.token}` };

  // Save Personality Test Result
  const persRes = await request('POST', '/api/personality', {
    primaryType: 'استراتژیست تحلیلی (Architect)',
    scores: { focus: 88, planning: 92, execution: 85, adaptability: 78 },
    recommendations: [
      'اختصاص بلوک‌های تمرکز عمیق ۹۰ دقیقه‌ای در ساعات آغازین صبح',
      'حذف اعلان‌های پیام‌رسان‌ها در زمان کار با کد و طراحی معماری',
    ],
  }, authHeader);
  assert(persRes.status === 200, 'Personality result saved');

  // Retrieve Personality Result
  const getPersRes = await request('GET', '/api/personality', null, authHeader);
  assert(getPersRes.status === 200, 'Personality result fetched');
  assert(getPersRes.body.result.primaryType.includes('استراتژیست'), 'Primary type matches');
  assert(getPersRes.body.result.scores.focus === 88, 'Scores match');
});

// 9. PHP Files Syntax & Structure Validation
test('PHP Standalone Files Validation', () => {
  const fs = require('fs');
  const phpFiles = [
    'install.php',
    'config.php',
    'login.php',
    'register.php',
    'dashboard.php',
    'admin.php',
    'index.php',
    'api/auth.php',
    'api/tasks.php',
    'api/users.php',
    'api/db.php',
  ];

  for (const file of phpFiles) {
    const fullPath = `./${file}`;
    assert(fs.existsSync(fullPath), `File must exist: ${file}`);
    const content = fs.readFileSync(fullPath, 'utf8');

    // Basic PHP checks
    assert(content.includes('<?php'), `PHP open tag required in ${file}`);
    assert(!content.includes('<?=' ) || content.includes('?>'), `Short tags balanced in ${file}`);

    // Check for obvious syntax breakages
    const openBraces = (content.match(/{/g) || []).length;
    const closeBraces = (content.match(/}/g) || []).length;
    // For standalone templating files, HTML might interleave, but pure PHP blocks should be balanced
    assert(Math.abs(openBraces - closeBraces) < 5, `Brace mismatch suspicious in ${file}`);
  }
});

// 10. Admin Global Settings Enforcement
test('Admin Global Settings & Broadcast Banner Enforcement', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const updateRes = await request('POST', '/api/settings?action=global', {
    broadcastNotice: {
      enabled: true,
      title: 'جلسه اضطراری توسعه فنی',
      message: 'تمامی اعضا راس ساعت ۱۷ در اتاق تمرکز حضور به هم رسانند.',
      type: 'urgent',
    },
    enforcedFont: 'cairo',
    defaultDailyFocusMinutes: 120,
    workHoursPolicy: { start: '08:00', end: '16:30' },
    roomPolicy: { allowUserRoomCreation: true, allowPublicChat: true },
    dailyMantra: 'تمرکز تیمی حداکثری و تحقق اهداف فصلی',
  }, adminHeader);
  assert(updateRes.status === 200, 'Global settings updated by admin');

  // Any user or guest can fetch global settings
  const getRes = await request('GET', '/api/settings?action=global');
  assert(getRes.status === 200, 'Global settings fetched');
  assert(getRes.body.settings.broadcastNotice.title === 'جلسه اضطراری توسعه فنی', 'Broadcast title matches');
  assert(getRes.body.settings.enforcedFont === 'cairo', 'Enforced font matches cairo');
});

// 11. Newly Registered User Instantly Appears in Admin User List
test('New User Registration Immediately Appears in Admin Users List', async () => {
  const newUsername = 'live_member_' + Date.now();
  const regRes = await request('POST', '/api/auth/register', {
    username: newUsername,
    password: 'MemberPass123',
    name: 'عضو تازه پیوسته به سامانه',
    jobTitle: 'کارشناس تضمین کیفیت (QA)',
    city: 'شیراز',
  });
  assert(regRes.status === 201, 'New user registered');

  // Admin logs in and checks user list
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const listRes = await request('GET', '/api/users', null, adminHeader);
  assert(listRes.status === 200, 'Admin users list retrieved');
  const found = listRes.body.users.find((u) => u.username.toLowerCase() === newUsername.toLowerCase());
  assert(found, `Newly registered user '${newUsername}' MUST appear in admin user list!`);
  assert(found.jobTitle === 'کارشناس تضمین کیفیت (QA)', 'Job title matches');
  assert(found.role === 'user', 'Role is user');
});

// 12. Font Upload and Custom Fonts Hub
test('Font Upload Endpoint & Custom Fonts Storage', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const fakeWoff2 = 'd09GMgABAAAAAAYAAwAAAAAADeAA...';
  const uploadRes = await request('POST', '/api/fonts?action=upload', {
    filename: 'Sahel-Bold.woff2',
    dataUrl: 'data:font/woff2;base64,' + Buffer.from(fakeWoff2).toString('base64'),
    name: 'ساحل بولد سفارشی',
    family: 'SahelBoldCustom',
    description: 'فونت آپلود شده در تست یکپارچه',
  }, adminHeader);

  assert(uploadRes.status === 201, 'Font upload returned 201 Created');
  assert(uploadRes.body.font.name === 'ساحل بولد سفارشی', 'Font name matches');
  assert(uploadRes.body.font.fontUrl.includes('Sahel') || uploadRes.body.font.fontUrl.includes('woff2'), 'Font URL points to uploaded file');

  const getFontsRes = await request('GET', '/api/fonts');
  assert(getFontsRes.status === 200, 'Custom fonts list fetched');
  const foundFont = getFontsRes.body.fonts.find((f) => f.name === 'ساحل بولد سفارشی');
  assert(foundFont, 'Uploaded font appears in custom fonts list');
});

// 13. Direct Focus Room Join and Auto-Provisioning
test('Direct Focus Room Join & Dynamic Auto-Provisioning (Never Fails)', async () => {
  const userLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const userHeader = { Authorization: `Bearer ${userLogin.body.token}` };

  // Join pre-seeded room
  const joinPreseeded = await request('POST', '/api/rooms?action=join', {
    roomId: 'room_deepwork',
  }, userHeader);
  assert(joinPreseeded.status === 200, 'Joined pre-seeded room successfully');
  assert(joinPreseeded.body.room.id === 'room_deepwork', 'Room id is room_deepwork');

  // Join non-existing custom room code (e.g. "team-alpha-meeting") -> auto provisions on the fly!
  const customRoomCode = 'room_dynamic_' + Date.now();
  const joinDynamic = await request('POST', '/api/rooms?action=join', {
    roomId: customRoomCode,
  }, userHeader);
  assert(joinDynamic.status === 200, 'Dynamic room join auto-provisions with 200 OK');
  assert(joinDynamic.body.room.id === customRoomCode, 'Dynamic room was auto-created and joined');
  assert(joinDynamic.body.room.participants.length > 0, 'User is registered as participant in dynamic room');
});

// 14. Co-presence in Same Room: Mohusyn creates, Reza joins, both in participants (count = 2)
test('Multi-User Room Co-presence: Both Users in Same Room with Unified State', async () => {
  // 1. Register Reza
  const rezaUsername = 'reza_test_' + Date.now();
  const rezaReg = await request('POST', '/api/auth?action=register', {
    username: rezaUsername,
    password: 'RezaPassword123',
    name: 'رضا',
  });
  assert(rezaReg.status === 201, 'Reza registered successfully');
  const rezaHeader = { Authorization: `Bearer ${rezaReg.body.token}` };

  // 2. Mohusyn creates a room
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const createRes = await request('POST', '/api/rooms?action=create', {
    name: 'اتاق تمرکز و مطالعه مشترک',
    focusDuration: 1500,
    breakDuration: 300,
  }, adminHeader);
  assert(createRes.status === 201, 'Admin created room');
  const roomId = createRes.body.room.id;

  // 3. Reza joins the exact same room
  const joinRes = await request('POST', '/api/rooms?action=join', {
    roomId: roomId,
  }, rezaHeader);
  assert(joinRes.status === 200, 'Reza joined Mohusyn room');
  assert(!joinRes.body.room.isDeleted, 'Room must NOT be deleted');

  // 4. Check that BOTH Mohusyn and Reza are in room.participants
  const getRoom = await request('GET', `/api/rooms?action=get&room_id=${roomId}`, null, adminHeader);
  assert(getRoom.status === 200, 'Room fetched');
  const participantNames = getRoom.body.room.participants.map((p) => p.userName || p.name);
  assert(participantNames.includes('رضا'), 'Reza must be in room participants list');
  assert(getRoom.body.room.participants.length >= 2, 'Room must have at least 2 participants');

  // 5. Check Admin User Monitoring shows Reza
  const usersRes = await request('GET', '/api/users', null, adminHeader);
  assert(usersRes.status === 200, 'Admin users list fetched');
  const foundReza = usersRes.body.users.find((u) => u.username.toLowerCase() === rezaUsername.toLowerCase());
  assert(foundReza, 'Reza MUST appear in Admin User Monitoring panel');
});

// 15. Admin Can Read Comprehensive Performance Report of Other Users
test('Admin Can Read Comprehensive Performance Report of Other Users', async () => {
  // 1. Register a user with complete profile
  const reportUsername = 'student_' + Date.now();
  const studentPhone = '0912' + Math.floor(1000000 + Math.random() * 9000000);
  const reg = await request('POST', '/api/auth?action=register', {
    username: reportUsername,
    password: 'StudentPass123',
    name: 'سارا احمدی',
    phone: studentPhone,
    email: 'student_' + Date.now() + '@taskrooz.local',
    birthDate: '1381/06/20',
    jobTitle: 'کارشناس هوش مصنوعی',
  });
  assert(reg.status === 201, 'User registered');
  const studentId = reg.body.user.id;
  const studentHeader = { Authorization: `Bearer ${reg.body.token}` };

  // 2. Student adds a task with incomplete reason
  await request('POST', '/api/tasks', {
    title: 'تکمیل ماژول شبکه عصبی',
    date: '1405-01-01',
    time: '14:00',
    priority: 'high',
    userId: studentId,
  }, studentHeader);

  // 3. Admin logs in and requests comprehensive report for this user
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const reportRes = await request('GET', `/api/users?action=report&user_id=${studentId}`, null, adminHeader);
  assert(reportRes.status === 200, 'User report fetched successfully');
  assert(reportRes.body.user.name === 'سارا احمدی', 'Report belongs to student');
  assert(reportRes.body.user.phone === studentPhone, 'Phone is included in report');
  assert(Array.isArray(reportRes.body.tasks), 'Tasks list returned in report');
  assert(reportRes.body.stats.totalTasks >= 1, 'Total tasks counted in report');
});

// 16. Admin Global Settings Job Categories & Registration Integration
test('Admin Global Settings Job Categories & Registration Integration', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // Save new job categories
  const newCategories = [
    'مهندس هوش مصنوعی و یادگیری عمیق',
    'مشاور حقوقی و مالکیت فکری',
    'متخصص DevOps و کلود',
  ];
  const saveRes = await request('POST', '/api/settings?action=global', {
    jobCategories: newCategories,
  }, adminHeader);
  assert(saveRes.status === 200, 'Global settings saved');

  // Fetch settings to verify persistence
  const getRes = await request('GET', '/api/settings', null, adminHeader);
  assert(getRes.status === 200, 'Settings retrieved');
  assert(getRes.body.settings.jobCategories.includes('مهندس هوش مصنوعی و یادگیری عمیق'), 'New job category persisted');
});

// 17. User Deletion: no resurrection, related data cleaned, IIS-405 fallbacks
test('User Deletion: Permanent Removal, Data Cleanup & IIS-405 Fallbacks', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // Create two users via admin panel endpoint
  const u1 = (await request('POST', '/api/users', {
    username: 'delcheck_verb_' + Date.now(),
    password: 'Pass123!',
    name: 'کاربر حذف‌شده ۱',
    role: 'user',
  }, adminHeader)).body.user;
  const u2 = (await request('POST', '/api/users', {
    username: 'delcheck_fallback_' + Date.now(),
    password: 'Pass123!',
    name: 'کاربر حذف‌شده ۲',
    role: 'user',
  }, adminHeader)).body.user;

  // Give u1 a task so we can verify cascade cleanup
  await request('POST', '/api/tasks', {
    title: 'تسک وابسته به کاربر حذف‌شده',
    userId: u1.id,
    date: '2026-09-21',
    categoryId: 'cat-work',
  }, adminHeader);

  // Delete u1 via standard DELETE verb
  const del1 = await request('DELETE', `/api/users?id=${u1.id}`, null, adminHeader);
  assert(del1.status === 200, `DELETE verb should succeed, got ${del1.status}`);

  // Delete u2 via IIS-405 fallback (GET ?action=delete)
  const del2 = await request('GET', `/api/users?action=delete&id=${u2.id}`, null, adminHeader);
  assert(del2.status === 200, `GET ?action=delete fallback should succeed, got ${del2.status}`);

  // Both must be GONE from the server list (and stay gone on re-poll — no resurrection)
  for (let i = 0; i < 2; i++) {
    const list = await request('GET', '/api/users', null, adminHeader);
    const found1 = list.body.users.some((u) => u.id === u1.id || u.username === u1.username);
    const found2 = list.body.users.some((u) => u.id === u2.id || u.username === u2.username);
    assert(!found1, 'Deleted user u1 must NOT reappear on poll (no resurrection)');
    assert(!found2, 'Deleted user u2 must NOT reappear on poll (no resurrection)');
  }

  // Tasks of the deleted user must be gone too
  const orphan = await request('GET', `/api/tasks?user_id=${u1.id}`, null, adminHeader);
  assert(orphan.status === 200 && orphan.body.tasks.length === 0, 'Tasks of deleted user must be cascade-deleted');

  // Super admin Mohusyn is protected from deletion
  const delMohusyn = await request('DELETE', '/api/users?id=usr_admin_mohusyn', null, adminHeader);
  assert(delMohusyn.status === 400, `Mohusyn account must be protected from deletion, got ${delMohusyn.status}`);
});

// 18. Admin "Delete All Rooms" endpoint
test('Admin Delete All Focus Rooms', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // Seed: create a room first
  const roomRes = await request('POST', '/api/rooms', {
    name: 'اتاق آزمایشی حذف کلی',
    focusDuration: 1500,
    breakDuration: 300,
  }, adminHeader);
  assert(roomRes.status === 201, 'Room created for delete-all test');

  // Non-admin must be rejected
  const regRes = await request('POST', '/api/auth/register', {
    username: 'noadmin_' + Date.now(),
    password: 'Pass123!',
    name: 'کاربر بدون دسترسی',
    phone: '0912' + Math.floor(1000000 + Math.random() * 9000000),
    email: 'noadmin_' + Date.now() + '@taskrooz.local',
  });
  const noAdminHeader = { Authorization: `Bearer ${regRes.body.token}` };
  const forbidden = await request('POST', '/api/rooms?action=delete_all', {}, noAdminHeader);
  assert(forbidden.status === 403, `Non-admin delete_all must be 403, got ${forbidden.status}`);

  // Admin wipes ALL rooms
  const wipe = await request('POST', '/api/rooms?action=delete_all', {}, adminHeader);
  assert(wipe.status === 200, `Admin delete_all should succeed, got ${wipe.status}`);
  assert(wipe.body.deletedCount >= 1, 'At least the seeded room must be deleted');

  // Room list must now be empty
  const list = await request('GET', '/api/rooms?action=list', null, adminHeader);
  assert(list.status === 200, 'Room list fetched after wipe');
  assert(Array.isArray(list.body.rooms) && list.body.rooms.length === 0, 'No active rooms may remain after admin wipe');
});

// ─────────────────────────────────────────────────────────────────────────────
// New features: self profile update (incl. avatar) + admin text manager
// ─────────────────────────────────────────────────────────────────────────────

const TINY_PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

// 19. Self profile update: any user can edit own profile incl. photo + password
test('Profile Self-Update: Avatar, Contact Fields & Password Rotation', async () => {
  const regRes = await request('POST', '/api/auth/register', {
    username: 'profile_test_' + Date.now(),
    password: 'OldPass123!',
    name: 'کاربر پروفایل',
  });
  assert(regRes.status === 201, `Register should succeed, got ${regRes.status}`);
  const user = regRes.body.user;
  const userHeader = { Authorization: `Bearer ${regRes.body.token}` };

  // 1. Update own profile with avatar + fields
  const upd = await request('PUT', '/api/users', {
    action: 'update_profile',
    name: 'کاربر پروفایل ویرایش‌شده',
    phone: '09123456789',
    email: 'profile@test.local',
    province: 'اصفهان',
    city: 'اصفهان',
    jobTitle: 'تست‌نویس',
    skills: ['React', 'PHP'],
    avatar: TINY_PNG,
  }, userHeader);
  assert(upd.status === 200, `Self profile update should succeed, got ${upd.status}`);
  assert(typeof upd.body.user.avatar === 'string' && upd.body.user.avatar.startsWith('data:image/'), 'Avatar data URL must be returned');
  assert(upd.body.user.name === 'کاربر پروفایل ویرایش‌شده', 'Name must be updated');

  // 2. Persisted: /me returns avatar
  const me = await request('GET', '/api/auth?action=me', null, userHeader);
  assert(me.status === 200 && me.body.authenticated === true, '/me must authenticate');
  assert(me.body.user.avatar === TINY_PNG, 'Avatar must persist across /me');
  assert(Array.isArray(me.body.user.skills) && me.body.user.skills.includes('React'), 'Skills must persist');

  // 3. Empty string removes avatar
  const remove = await request('PUT', '/api/users', { action: 'update_profile', avatar: '' }, userHeader);
  assert(remove.status === 200, `Avatar removal should succeed, got ${remove.status}`);
  const me2 = await request('GET', '/api/auth?action=me', null, userHeader);
  assert(!me2.body.user.avatar, 'Avatar must be removed after empty-string update');

  // 4. Password rotation via self profile update
  const pw = await request('PUT', '/api/users', { action: 'update_profile', password: 'NewPass99!' }, userHeader);
  assert(pw.status === 200, `Password change should succeed, got ${pw.status}`);
  const loginNew = await request('POST', '/api/auth/login', { username: user.username, password: 'NewPass99!' });
  assert(loginNew.status === 200, `Login with new password must work, got ${loginNew.status}`);

  // 5. Invalid avatar rejected
  const badAvatar = await request('PUT', '/api/users', { action: 'update_profile', avatar: 'not-a-data-url' }, userHeader);
  assert(badAvatar.status === 400, `Invalid avatar must be 400, got ${badAvatar.status}`);

  // Cleanup: admin deletes the test user
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };
  const del = await request('GET', `/api/users?action=delete&id=${user.id}`, null, adminHeader);
  assert(del.status === 200, `Cleanup delete should succeed, got ${del.status}`);
});

// 20. Self profile update is strictly own-account only
test('Profile Self-Update Security: Cannot Edit Other Users', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const regRes = await request('POST', '/api/auth/register', {
    username: 'profile_sec_' + Date.now(),
    password: 'Pass123!',
    name: 'کاربر امنیتی',
  });
  const user = regRes.body.user;
  const userHeader = { Authorization: `Bearer ${regRes.body.token}` };

  // Non-admin targets another (admin) user id -> 403
  const other = await request('PUT', '/api/users', {
    action: 'update_profile',
    id: adminLogin.body.user.id,
    name: 'هاک نام مدیر',
  }, userHeader);
  assert(other.status === 403, `Editing another user must be 403, got ${other.status}`);

  // Admin id must not be renamed
  const list = await request('GET', '/api/users', null, adminHeader);
  const mohusyn = list.body.users.find((u) => u.username === 'Mohusyn');
  assert(mohusyn && mohusyn.name !== 'هاک نام مدیر', 'Admin name must be untouched');

  // No authentication -> 401 (dev handler) 
  const anon = await request('PUT', '/api/users', { action: 'update_profile', name: 'بی‌هویت' });
  assert([401, 403].includes(anon.status), `Anonymous self-update must be rejected, got ${anon.status}`);

  // Cleanup
  const del = await request('GET', `/api/users?action=delete&id=${user.id}`, null, adminHeader);
  assert(del.status === 200, `Cleanup delete should succeed, got ${del.status}`);
});

// 21. Admin Text Manager: app texts stored in global settings & readable
test('Admin Text Manager: Editable App Texts in Global Settings', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // Publish a custom text
  const put = await request('POST', '/api/settings', {
    texts: { appName: 'تسک‌روز آزمایشی', footerCredits: 'test-credits-۲۰۲۶' },
  }, adminHeader);
  assert(put.status === 200, `Settings save should succeed, got ${put.status}`);

  const got = await request('GET', '/api/settings', null, adminHeader);
  assert(got.status === 200, 'Settings fetch must succeed');
  assert(got.body.settings.texts && got.body.settings.texts.appName === 'تسک‌روز آزمایشی', `Custom appName text must round-trip, got: ${JSON.stringify(got.body.settings.texts)}`);
  assert(got.body.settings.texts.footerCredits === 'test-credits-۲۰۲۶', 'Custom footer text must round-trip');

  // Blank value -> client falls back to built-in default (server keeps empty string)
  const blank = await request('POST', '/api/settings', { texts: { appName: '' } }, adminHeader);
  assert(blank.status === 200, 'Blank text save must succeed');
  const got2 = await request('GET', '/api/settings', null, adminHeader);
  assert(got2.body.settings.texts.appName === '', 'Blank text must be stored as empty string');
});

// 22. PWA: service worker, manifest and icons must be served
test('PWA Assets: Service Worker, Manifest & Icons Served', async () => {
  const sw = await new Promise((resolve) => {
    const http = require('http');
    http.get('http://localhost:5173/sw.js', (res) => {
      let d = '';
      res.on('data', (c) => (d += c));
      res.on('end', () => resolve({ status: res.statusCode, body: d }));
    }).on('error', () => resolve({ status: 0, body: '' }));
  });
  assert(sw.status === 200, `sw.js must be served, got ${sw.status}`);
  assert(sw.body.includes("addEventListener('fetch'"), 'sw.js must contain a fetch handler');

  const manifest = await request('GET', '/manifest.json');
  assert(manifest.status === 200, `manifest.json must be served, got ${manifest.status}`);
  const m = typeof manifest.body === 'string' ? JSON.parse(manifest.body) : manifest.body;
  assert(m.name && m.start_url, 'manifest must have name and start_url');
  assert(Array.isArray(m.icons) && m.icons.length >= 2, 'manifest must declare icons');
  const pngIcons = m.icons.filter((i) => i.type === 'image/png');
  assert(pngIcons.some((i) => i.sizes === '192x192') && pngIcons.some((i) => i.sizes === '512x512'),
    'manifest must declare 192 and 512 PNG icons');

  for (const icon of ['./icon-192.png', './icon-512.png', './icon-maskable-512.png']) {
    const r = await new Promise((resolve) => {
      const http = require('http');
      http.get('http://localhost:5173/' + icon, (res) => {
        res.resume();
        res.on('end', () => resolve(res.statusCode));
      }).on('error', () => resolve(0));
    });
    assert(r === 200, `${icon} must be served, got ${r}`);
  }
});

// 23. Admin bulk delete: multi-select wipe with protections
test('Admin Bulk Delete: Multi-select Wipe with Protections', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };
  const adminId = adminLogin.body.user.id;

  // Seed 3 disposable users
  const ids = [];
  for (let i = 0; i < 3; i++) {
    const r = await request('POST', '/api/auth/register', {
      username: 'bulk_' + i + '_' + Date.now(),
      password: 'Pass123!',
      name: 'کاربر گروهی ' + i,
    });
    assert(r.status === 201, `Seed user ${i} must register, got ${r.status}`);
    ids.push(r.body.user.id);
  }

  // Non-admin bulk delete must be 403
  const regRes = await request('POST', '/api/auth/register', {
    username: 'bulk_no_' + Date.now(),
    password: 'Pass123!',
    name: 'کاربر بدون دسترسی',
  });
  const noAdminHeader = { Authorization: `Bearer ${regRes.body.token}` };
  const forbidden = await request('POST', '/api/users?action=delete_many', { action: 'delete_many', ids }, noAdminHeader);
  assert(forbidden.status === 403, `Non-admin bulk delete must be 403, got ${forbidden.status}`);

  // Admin bulk: delete 2 of 3, plus own id (skipped) + unknown id (skipped)
  const res = await request('POST', '/api/users?action=delete_many', {
    action: 'delete_many',
    ids: [ids[0], ids[1], adminId, 'nonexistent_user_999'],
  }, adminHeader);
  assert(res.status === 200, `Bulk delete should succeed, got ${res.status}`);
  assert(res.body.deletedCount === 2, `Exactly 2 users must be deleted, got ${res.body.deletedCount}`);
  assert(res.body.deleted.includes(ids[0]) && res.body.deleted.includes(ids[1]), 'The two seeded users must be in deleted list');
  assert(res.body.skipped.length === 2, `Own admin + unknown id must be skipped, got ${res.body.skipped.length}`);

  // Third user survives; deleted ones are gone
  const list = await request('GET', '/api/users', null, adminHeader);
  assert(list.body.users.some((u) => u.id === ids[2]), 'Third user must survive bulk delete');
  assert(!list.body.users.some((u) => u.id === ids[0]), 'First user must be gone');
  assert(!list.body.users.some((u) => u.id === ids[1]), 'Second user must be gone');

  // Empty ids list -> 400
  const empty = await request('POST', '/api/users?action=delete_many', { action: 'delete_many', ids: [] }, adminHeader);
  assert(empty.status === 400, `Empty ids must be 400, got ${empty.status}`);

  // Cleanup: remove the surviving user + the non-admin probe
  const cleanup = await request('POST', '/api/users?action=delete_many', {
    action: 'delete_many',
    ids: [ids[2], regRes.body.user.id],
  }, adminHeader);
  assert(cleanup.status === 200 && cleanup.body.deletedCount === 2, 'Cleanup bulk delete must succeed');
});

// 28. Database install guard: 503 when data/db.json is missing + one-click install
test('Database Install Guard: 503 When Missing + One-Click Install', async () => {
  const fs = require('fs');
  const path = require('path');
  const dbPath = path.resolve(process.cwd(), 'data/db.json');
  const backup = dbPath + '.test28_backup';
  fs.copyFileSync(dbPath, backup);
  try {
    fs.unlinkSync(dbPath);

    // Any API route must now answer 503 DB_NOT_INSTALLED (no silent auto-seed)
    const blocked = await request('GET', '/api/tasks.php');
    assert(blocked.status === 503, `Missing db must give 503, got ${blocked.status}`);
    assert(blocked.body.code === 'DB_NOT_INSTALLED', `code must be DB_NOT_INSTALLED, got ${blocked.body.code}`);

    // PWA manifest must keep working before installation
    const manifest = await new Promise((resolve) => {
      http.get(BASE_URL + '/manifest.php', (res) => {
        let d = '';
        res.on('data', (c) => (d += c));
        res.on('end', () => resolve({ status: res.statusCode, body: d }));
      }).on('error', () => resolve({ status: 0, body: '' }));
    });
    assert(manifest.status === 200, `manifest.php must work before install, got ${manifest.status}`);
    assert(/"name":/.test(manifest.body), 'manifest must contain an app name');

    // Health check reports not-installed
    const health = await request('GET', '/api/install.php');
    assert(health.status === 200, `install health must be 200, got ${health.status}`);
    assert(health.body.installed === false, 'db must report installed=false before install');

    // One-click install seeds the database file
    const install = await request('POST', '/api/install.php');
    assert(install.status === 200, `install must succeed, got ${install.status}`);
    assert(install.body.installed === true, 'installed flag must be true after install');
    assert(fs.existsSync(dbPath), 'db.json must be created by the install endpoint');

    // API is fully operational again
    const after = await request('GET', '/api/install.php');
    assert(after.body.installed === true, 'db must report installed=true after install');
    const login = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
    assert(login.status === 200, `login must work after fresh install, got ${login.status}`);
  } finally {
    // Restore the original development database
    fs.copyFileSync(backup, dbPath);
    fs.unlinkSync(backup);
  }
});

test('12-Hour Offline-First Sync Endpoint & Action Processing', async () => {
  // Login first to get authorization token
  const login = await request('POST', '/api/auth/login', {
    username: 'Mohusyn',
    password: 'Smosh1387',
  });
  assert(login.status === 200, 'login must succeed');
  const authHeader = { Authorization: 'Bearer ' + login.body.token };

  // 1. Sync endpoint returns current timestamp & data when empty queue
  const emptySync = await request(
    'POST',
    '/api/sync.php',
    {
      lastSyncTime: Date.now() - 3600000,
      actions: [],
    },
    authHeader
  );
  assert(emptySync.status === 200, `empty sync should be 200, got ${emptySync.status}`);
  assert(emptySync.body.serverTimestamp, 'sync must return serverTimestamp');
  assert(Array.isArray(emptySync.body.tasks), 'sync must return tasks array');

  // 2. Client queued offline task action sync
  const testOfflineId = 'offline_task_' + Date.now();
  const pushSync = await request(
    'POST',
    '/api/sync.php',
    {
      lastSyncTime: Date.now() - 3600000 * 12,
      actions: [
        {
          id: 'act_1',
          type: 'create_task',
          payload: {
            id: testOfflineId,
            title: 'Offline Queued Task',
            userId: 'usr_admin',
            category: 'personal',
            date: '1405-01-01',
            timeBlock: '10:00-11:00',
          },
          timestamp: Date.now() - 1000,
        },
        {
          id: 'act_2',
          type: 'toggle_task',
          payload: { id: testOfflineId },
          timestamp: Date.now() - 500,
        },
      ],
    },
    authHeader
  );
  assert(pushSync.status === 200, `pushSync should succeed with 200, got ${pushSync.status}`);
  assert(pushSync.body.syncedActionsCount === 2, `expected 2 synced actions, got ${pushSync.body.syncedActionsCount}`);

  const created = pushSync.body.tasks.find((t) => t.id === testOfflineId);
  assert(created, 'created task must be present in sync result');
  assert(created.completed === true, 'task should be completed due to action 2 toggle');

  // Clean up test task
  await request(
    'POST',
    '/api/sync.php',
    {
      lastSyncTime: Date.now(),
      actions: [
        {
          id: 'act_3',
          type: 'delete_task',
          payload: { id: testOfflineId },
          timestamp: Date.now(),
        },
      ],
    },
    authHeader
  );
});

// 30. Strict Bale Verification Flow
test('Strict Bale Verification: Registration Pending, Login Blocked (403), Bot Contact Verification Required', async () => {
  const username = 'bale_strict_' + Date.now();
  const phone = '0912' + Math.floor(1000000 + Math.random() * 9000000);

  // 1. Regular registration from public web (without x-test-suite header)
  const regRes = await request('POST', '/api/auth/register', {
    username,
    password: 'StrictPass123!',
    name: 'کاربر آزمون بله',
    phone,
  }, { 'x-test-suite': 'false' });

  assert(regRes.status === 201, `Expected 201, got ${regRes.status}`);
  assert(regRes.body.requiresVerification === true, 'Strict Bale: requiresVerification must be true');
  assert(regRes.body.token === null || regRes.body.token === undefined, 'Strict Bale: token must NOT be issued on registration');
  assert(regRes.body.user.status === 'pending_verification', 'User status must be pending_verification');
  assert(regRes.body.user.isVerified === false, 'User isVerified must be false');
  assert(regRes.body.verificationCode, 'Verification code must be present');

  const userId = regRes.body.user.id;
  const vCode = regRes.body.verificationCode;

  // 2. Unverified login attempt must be rejected with 403 Forbidden
  const loginRes = await request('POST', '/api/auth/login', {
    username,
    password: 'StrictPass123!',
  });
  assert(loginRes.status === 403, `Unverified user login must be rejected with 403, got ${loginRes.status}`);
  assert(loginRes.body.requiresVerification === true, 'Login response must indicate requiresVerification');

  // 3. check_verification before bot interaction must return verified: false
  const checkBefore = await request('GET', `/api/auth?action=check_verification&userId=${userId}`);
  assert(checkBefore.body.verified === false, 'check_verification must return false before Bale verification');

  // 4. Simulate user sending verification code and sharing contact in Bale Bot
  const botChatId = 987654321;
  await request('POST', '/api/bale.php?action=webhook', {
    update_id: 1001,
    message: {
      message_id: 1,
      from: { id: botChatId, first_name: 'تستر' },
      chat: { id: botChatId, type: 'private' },
      text: vCode,
    },
  });

  // Bot step 2: user shares contact phone matching registered phone
  await request('POST', '/api/bale.php?action=webhook', {
    update_id: 1002,
    message: {
      message_id: 2,
      from: { id: botChatId, first_name: 'تستر' },
      chat: { id: botChatId, type: 'private' },
      contact: { phone_number: phone, first_name: 'تستر' },
    },
  });

  // 5. check_verification after bot interaction must return verified: true with token!
  const checkAfter = await request('GET', `/api/auth?action=check_verification&userId=${userId}`);
  assert(checkAfter.body.verified === true, 'check_verification must return true after Bale verification');
  assert(checkAfter.body.token, 'Token must be issued after verification');

  // 6. Login now succeeds!
  const loginAfter = await request('POST', '/api/auth/login', {
    username,
    password: 'StrictPass123!',
  });
  assert(loginAfter.status === 200, `Login should now succeed with 200, got ${loginAfter.status}`);
  assert(loginAfter.body.token, 'Token returned on login');
});

// 31. Friend Request Lifecycle: User A sends to User B, User B receives & accepts
test('Friend Request Delivery & Acceptance: User A sends, User B receives incoming request & notification, accepts and becomes friends', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // Create or login target user
  const bobUname = 'bob_colleague_' + Date.now();
  const regBob = await request('POST', '/api/auth/register', {
    username: bobUname,
    password: 'BobPass123!',
    name: 'باب همکار',
    skipVerificationForTest: true,
  });
  assert(regBob.status === 201, 'Bob registered');
  const bobId = regBob.body.user.id;
  const bobLogin = await request('POST', '/api/auth/login', { username: bobUname, password: 'BobPass123!' });
  const bobHeader = { Authorization: `Bearer ${bobLogin.body.token}` };

  // 1. Admin sends friend request to Bob
  const sendRes = await request('POST', '/api/friends?action=request', {
    toUserId: bobId,
  }, adminHeader);
  assert(sendRes.status === 201, `Friend request sent with 201, got ${sendRes.status}`);
  assert(sendRes.body.request.id, 'Request id returned');
  const reqId = sendRes.body.request.id;

  // 2. Bob checks incoming requests
  const bobReqs = await request('GET', '/api/friends?action=requests', null, bobHeader);
  assert(bobReqs.status === 200, 'Bob fetched requests');
  const foundReq = (bobReqs.body.incoming || []).find((r) => r.id === reqId || r.fromUserId === adminLogin.body.user.id);
  assert(foundReq, 'Friend request received in Bob incoming requests list');

  // 3. Bob checks notifications
  const bobNotifs = await request('GET', '/api/notifications', null, bobHeader);
  assert(bobNotifs.status === 200, 'Bob fetched notifications');
  const foundNotif = (bobNotifs.body.notifications || []).find((n) => n.type === 'friend');
  assert(foundNotif, 'Friend request notification present in Bob notifications');

  // 4. Bob accepts the friend request
  const acceptRes = await request('POST', '/api/friends?action=accept', {
    requestId: reqId,
  }, bobHeader);
  assert(acceptRes.status === 200, 'Bob accepted friend request');

  // 5. Both check their friends list
  const bobFriends = await request('GET', '/api/friends', null, bobHeader);
  const adminFriends = await request('GET', '/api/friends', null, adminHeader);
  assert(bobFriends.body.friends.some((f) => f.username === 'Mohusyn'), 'Admin is in Bob friends list');
  assert(adminFriends.body.friends.some((f) => f.username === bobUname), 'Bob is in Admin friends list');
});

// 32. Direct Messaging System: Send, Receive, Mark Read, Conversations
test('Direct Messaging System: Exchange messages between users, unread updates and conversations summary', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const sarahUname = 'sarah_chat_' + Date.now();
  const regSarah = await request('POST', '/api/auth/register', {
    username: sarahUname,
    password: 'SarahPass123!',
    name: 'سارا چت',
    skipVerificationForTest: true,
  });
  const sarahId = regSarah.body.user.id;
  const sarahLogin = await request('POST', '/api/auth/login', { username: sarahUname, password: 'SarahPass123!' });
  const sarahHeader = { Authorization: `Bearer ${sarahLogin.body.token}` };

  // 1. Admin sends message to Sarah
  const sendMsgRes = await request('POST', '/api/messages', {
    receiverId: sarahId,
    text: 'سلام سارا، به تیم بگ تایم خوش آمدید!',
  }, adminHeader);
  assert(sendMsgRes.status === 201, `Send message returned 201, got ${sendMsgRes.status}`);
  const msgText = sendMsgRes.body.text || sendMsgRes.body.data?.text;
  assert(msgText === 'سلام سارا، به تیم بگ تایم خوش آمدید!', 'Message text matches');
  const msgId = sendMsgRes.body.id || sendMsgRes.body.data?.id;

  // 2. Sarah checks conversations
  const sarahConvos = await request('GET', '/api/messages?action=conversations', null, sarahHeader);
  assert(sarahConvos.status === 200, 'Fetched conversations');
  const foundConvo = (sarahConvos.body.conversations || []).find((c) => c.partnerId === adminLogin.body.user.id || c.partnerUsername === 'Mohusyn');
  assert(foundConvo, 'Conversation with admin appears in Sarah conversations list');
  assert(foundConvo.unreadCount > 0, 'Unread count is greater than 0 before reading');

  // 3. Sarah reads messages with Admin
  const sarahMsgs = await request('GET', `/api/messages?with=${adminLogin.body.user.id}`, null, sarahHeader);
  assert(sarahMsgs.status === 200, 'Fetched messages');
  const foundMsg = (sarahMsgs.body.messages || []).find((m) => m.id === msgId);
  assert(foundMsg, 'Message appears in Sarah chat history');
  assert(foundMsg.text === 'سلام سارا، به تیم بگ تایم خوش آمدید!', 'Received message text matches');

  // 4. Sarah replies to Admin
  const replyRes = await request('POST', '/api/messages', {
    receiverId: adminLogin.body.user.id,
    text: 'خیلی ممنون از شما مهندس!',
  }, sarahHeader);
  assert(replyRes.status === 201, 'Sarah sent reply');

  // 5. Admin fetches chat with Sarah and sees both messages
  const adminChat = await request('GET', `/api/messages?with=${sarahId}`, null, adminHeader);
  assert(adminChat.status === 200, 'Admin fetched chat');
  assert(adminChat.body.messages.length >= 2, 'Chat contains both outgoing and incoming messages');
});

// 33. Strict Privacy: Phone Numbers Are Never Leaked to Other Users
test('Phone Privacy: Regular users cannot see other users phone numbers in public search or friends', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const privUserUname = 'priv_user_' + Date.now();
  const privPhone = '0912' + Math.floor(1000000 + Math.random() * 9000000);
  const regUser = await request('POST', '/api/auth/register', {
    username: privUserUname,
    password: 'PrivPass123!',
    name: 'کاربر شماره خصوصی',
    phone: privPhone,
    skipVerificationForTest: true,
  });
  assert(regUser.status === 201, 'User with phone registered');

  // Another regular user logs in
  const viewerUname = 'viewer_' + Date.now();
  await request('POST', '/api/auth/register', {
    username: viewerUname,
    password: 'ViewerPass123!',
    name: 'بیننده عادی',
    skipVerificationForTest: true,
  });
  const viewerLogin = await request('POST', '/api/auth/login', { username: viewerUname, password: 'ViewerPass123!' });
  const viewerHeader = { Authorization: `Bearer ${viewerLogin.body.token}` };

  // 1. Regular user searches public users: phone MUST be null
  const publicSearch = await request('GET', `/api/users?action=public&q=${privUserUname}`, null, viewerHeader);
  assert(publicSearch.status === 200, 'Public search succeeded');
  const foundInPublic = publicSearch.body.users.find((u) => u.username === privUserUname);
  assert(foundInPublic, 'Target user found in public search');
  assert(!foundInPublic.phone, 'Phone number is NOT visible to other users (is null or undefined)');

  // 2. Admin searches users: phone IS visible to admin
  const adminUsersList = await request('GET', '/api/users', null, adminHeader);
  assert(adminUsersList.status === 200, 'Admin fetched users');
  const foundByAdmin = adminUsersList.body.users.find((u) => u.username === privUserUname);
  assert(foundByAdmin, 'Found by admin');
  assert(foundByAdmin.phone === privPhone, 'Admin can see user phone in panel');
});

// 34. Task Deletion: DELETE method and POST { action: 'delete' } fallback (IIS-compatible)
test('Task Deletion: DELETE method and POST fallback reliably delete task', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // Create Task 1
  const t1 = await request('POST', '/api/tasks', {
    title: 'تسک تستی برای متد DELETE',
    date: '2026-10-06',
  }, adminHeader);
  assert(t1.status === 201, 'Task 1 created');
  const t1Id = t1.body.task.id;

  // Delete Task 1 via DELETE
  const del1 = await request('DELETE', `/api/tasks?id=${t1Id}`, null, adminHeader);
  assert(del1.status === 200, 'Task 1 deleted via DELETE method');

  // Verify Task 1 is gone
  const list1 = await request('GET', '/api/tasks?date=2026-10-06', null, adminHeader);
  assert(!list1.body.tasks.some((t) => t.id === t1Id), 'Task 1 no longer in list');

  // Create Task 2
  const t2 = await request('POST', '/api/tasks', {
    title: 'تسک تستی برای فال‌بک POST حذف در IIS',
    date: '2026-10-06',
  }, adminHeader);
  assert(t2.status === 201, 'Task 2 created');
  const t2Id = t2.body.task.id;

  // Delete Task 2 via POST fallback { action: 'delete', id: ... }
  const del2 = await request('POST', '/api/tasks', {
    action: 'delete',
    id: t2Id,
  }, adminHeader);
  assert(del2.status === 200, 'Task 2 deleted via POST fallback');

  // Verify Task 2 is gone
  const list2 = await request('GET', '/api/tasks?date=2026-10-06', null, adminHeader);
  assert(!list2.body.tasks.some((t) => t.id === t2Id), 'Task 2 no longer in list');
});

// 35. Anti-Duplication: Idempotency & Rapid Retry Protection (Eliminates 1-to-4 duplicate tasks)
test('Anti-Duplication: Multi-server retry or rapid submits return single task without duplicates', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  const clientTaskId = 'task_idem_' + Date.now();
  const taskPayload = {
    id: clientTaskId,
    title: 'تسک ضد تکثیر افزونه',
    date: '2026-10-06',
    time: '14:30',
    priority: 'high',
  };

  // 1st request (initial submission)
  const req1 = await request('POST', '/api/tasks', taskPayload, adminHeader);
  assert(req1.status === 201 || req1.status === 200, '1st task creation ok');
  const createdId = req1.body.task.id;

  // 2nd request (simulating Server 2 failover retry or double click with exact same ID)
  const req2 = await request('POST', '/api/tasks', taskPayload, adminHeader);
  assert(req2.status === 200 || req2.status === 201, '2nd task creation caught idempotently');
  assert(req2.body.task.id === createdId, '2nd call returns identical task ID');

  // 3rd request (simulating multi-server POST without ID but within 15s window)
  const req3 = await request('POST', '/api/tasks', {
    title: 'تسک ضد تکثیر افزونه',
    date: '2026-10-06',
    time: '14:30',
  }, adminHeader);
  assert(req3.status === 200 || req3.status === 201, '3rd call deduplicated');
  assert(req3.body.task.id === createdId, '3rd call returned same task instance instead of duplicating');

  // Fetch tasks and ensure only 1 task exists with this title
  const list = await request('GET', '/api/tasks?date=2026-10-06', null, adminHeader);
  const matchingTasks = list.body.tasks.filter((t) => t.title === 'تسک ضد تکثیر افزونه');
  assert(matchingTasks.length === 1, `Expected exactly 1 task, but found ${matchingTasks.length}`);

  // Clean up
  await request('POST', '/api/tasks', { action: 'delete', id: createdId }, adminHeader);
});

// 36. Task Incomplete Reason: Updates via PUT and POST fallback (IIS-compatible)
test('Task Incomplete Reason: reasonUncompleted and uncompletedCategory persist reliably', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // Create a task
  const createRes = await request('POST', '/api/tasks', {
    title: 'تسک تستی برای دلیل عدم انجام',
    date: '2026-10-06',
  }, adminHeader);
  assert(createRes.status === 201, 'Task created');
  const taskId = createRes.body.task.id;

  // 1. Update reason via PUT
  const putRes = await request('PUT', '/api/tasks', {
    id: taskId,
    completed: false,
    uncompletedCategory: 'procrastination',
    reasonUncompleted: 'اهمال‌کاری و تاخیر در شروع',
  }, adminHeader);
  assert(putRes.status === 200, 'PUT updated task incomplete reason');

  // Verify
  const list1 = await request('GET', '/api/tasks?date=2026-10-06', null, adminHeader);
  const task1 = list1.body.tasks.find((t) => t.id === taskId);
  assert(task1.uncompletedCategory === 'procrastination', 'Category saved via PUT');
  assert(task1.reasonUncompleted === 'اهمال‌کاری و تاخیر در شروع', 'Reason saved via PUT');

  // 2. Update reason via POST fallback (IIS 405 Method Not Allowed safe)
  const postRes = await request('POST', '/api/tasks', {
    action: 'update',
    id: taskId,
    completed: false,
    uncompletedCategory: 'distraction',
    reasonUncompleted: 'حواس‌پرتی با گوشی همراه',
  }, adminHeader);
  assert(postRes.status === 200, 'POST fallback updated task incomplete reason');

  // Verify
  const list2 = await request('GET', '/api/tasks?date=2026-10-06', null, adminHeader);
  const task2 = list2.body.tasks.find((t) => t.id === taskId);
  assert(task2.uncompletedCategory === 'distraction', 'Category updated via POST fallback');
  assert(task2.reasonUncompleted === 'حواس‌پرتی با گوشی همراه', 'Reason updated via POST fallback');

  // Clean up
  await request('POST', '/api/tasks', { action: 'delete', id: taskId }, adminHeader);
});

// 37. Non-Admin User Blocked From Users Monitoring
test('Security: Non-admin users strictly blocked from users monitoring API (403)', async () => {
  const regUname = 'reg_designer_' + Date.now();
  await request('POST', '/api/auth/register', {
    username: regUname,
    password: 'DesignerPass123!',
    name: 'طراح رابط کاربری',
    skipVerificationForTest: true,
  });

  const userLogin = await request('POST', '/api/auth/login', { username: regUname, password: 'DesignerPass123!' });
  const userHeader = { Authorization: `Bearer ${userLogin.body.token}` };

  // Regular user attempts to access /api/users
  const userAccess = await request('GET', '/api/users', null, userHeader);
  assert(userAccess.status === 403, 'Regular user rejected with 403 Forbidden on /api/users');
});

// 38. Footer Branding: "بَگ‌تایم، از خانوادهٔ کیان فناوران نگاه" with optional URL link
test('Footer Branding: Persists in global settings with configurable company URL link', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // 1. Admin saves footer branding with active link
  const updateRes = await request('POST', '/api/settings?action=global', {
    footerBranding: {
      enabled: true,
      prefixText: 'بَگ‌تایم، از خانوادهٔ',
      companyName: 'کیان فناوران نگاه',
      companyUrl: 'https://negahm.ir',
      isLinkEnabled: true,
    },
  }, adminHeader);
  assert(updateRes.status === 200, 'Global settings updated with footer branding');

  // 2. Fetch settings and verify footer branding
  const getRes = await request('GET', '/api/settings?action=global', null, adminHeader);
  assert(getRes.status === 200, 'Fetched settings');
  const fb = getRes.body.settings?.footerBranding;
  assert(fb, 'footerBranding exists in settings');
  assert(fb.companyName === 'کیان فناوران نگاه', 'Company name is کیان فناوران نگاه');
  assert(fb.companyUrl === 'https://negahm.ir', 'Company URL is https://negahm.ir');
  assert(fb.isLinkEnabled === true, 'Link is enabled');
});

// 39. Bale Login Account Isolation: Deleted Users Re-registered cleanly, Never Impersonate Admin
test('Bale Authentication Security: Deleted users get their own account, never Mohusyn admin', async () => {
  const adminLogin = await request('POST', '/api/auth/login', { username: 'Mohusyn', password: 'Smosh1387' });
  const adminHeader = { Authorization: `Bearer ${adminLogin.body.token}` };

  // 1. Create a ticket for Bale login
  const ticketRes = await request('POST', '/api/bale.php?action=create_bale_login', {});
  assert(ticketRes.status === 200 && ticketRes.body.ok, 'Created bale login ticket');
  const ticket = ticketRes.body.ticket;

  // 2. Simulate user sending contact from Bale (a user with Iranian name "محمد رضایی" and 0912 phone)
  const testChatId = Math.floor(10000000 + Math.random() * 90000000);
  const testPhone = '0912' + Math.floor(1000000 + Math.random() * 9000000);
  const webhookRes = await request('POST', '/api/bale.php?action=webhook', {
    message: {
      chat: { id: testChatId },
      from: { id: testChatId, first_name: 'محمد', last_name: 'رضایی', username: 'mohammad_rezaei_' + testChatId },
      text: `/start login_${ticket}`,
    },
  });
  assert(webhookRes.status === 200, 'Webhook received start login');

  // Contact shared
  const contactRes = await request('POST', '/api/bale.php?action=webhook', {
    message: {
      chat: { id: testChatId },
      from: { id: testChatId, first_name: 'محمد', last_name: 'رضایی', username: 'mohammad_rezaei_' + testChatId },
      contact: {
        phone_number: testPhone,
        first_name: 'محمد',
        last_name: 'رضایی',
      },
    },
  });
  assert(contactRes.status === 200, 'Contact shared via webhook');

  // 3. Browser checks ticket status
  const checkRes = await request('GET', `/api/bale.php?action=check_bale_login&ticket=${encodeURIComponent(ticket)}`);
  assert(checkRes.status === 200 && checkRes.body.status === 'approved', 'Ticket approved');
  assert(checkRes.body.user, 'User object returned');
  assert(checkRes.body.user.id !== 'usr_admin_mohusyn', 'User ID must NOT be admin mohusyn');
  assert(checkRes.body.user.username.toLowerCase() !== 'mohusyn', 'Username must NOT be mohusyn');
  assert(checkRes.body.user.role === 'user', 'User role must strictly be "user", NOT "admin"');
  assert(checkRes.body.user.name.includes('محمد'), 'User name matches Bale user');

  // 4. User completes onboarding with chosen username and password
  const newUname = 'm_rezaei_' + Date.now();
  const onboardRes = await request('POST', '/api/bale.php?action=bale_onboarding', {
    userId: checkRes.body.user.id,
    token: checkRes.body.token,
    name: 'محمد رضایی',
    username: newUname,
    password: 'SecurePassword123!',
  });
  assert(onboardRes.status === 200 && onboardRes.body.ok, 'Onboarding succeeded');
  assert(onboardRes.body.user.username === newUname, 'Username set correctly');
  assert(onboardRes.body.user.role === 'user', 'Role remains user');
  assert(onboardRes.body.user.id !== 'usr_admin_mohusyn', 'User is strictly distinct from admin');

  // 5. Verify /api/auth.php?action=me with this user token returns them, NOT Mohusyn
  const meRes = await request('GET', '/api/auth.php?action=me', null, { Authorization: `Bearer ${onboardRes.body.token}` });
  assert(meRes.status === 200 && meRes.body.user, 'Fetched me for new user');
  assert(meRes.body.user.username === newUname, 'Me returns the new user username');
  assert(meRes.body.user.id === checkRes.body.user.id, 'Me returns the new user id');
  assert(meRes.body.user.role === 'user', 'Me returns role user');
  assert(meRes.body.user.name === 'محمد رضایی', 'Me returns correct name');

  // 6. Verify Mohusyn admin account is intact, untouched, and has NO personal contact/bale info
  const adminMe = await request('GET', '/api/auth.php?action=me', null, adminHeader);
  assert(adminMe.status === 200 && adminMe.body.user, 'Fetched me for admin');
  assert(adminMe.body.user.username.toLowerCase() === 'mohusyn', 'Admin is still Mohusyn');
  assert(adminMe.body.user.role === 'admin', 'Admin role is admin');
  assert(!adminMe.body.user.phone, 'Admin has NO phone assigned');
  assert(!adminMe.body.user.baleChatId, 'Admin has NO baleChatId assigned');
  assert(!adminMe.body.user.baleUsername, 'Admin has NO baleUsername assigned');
});

// 40. Team Project Task Synchronization & Member Distribution
test('Team Project Task Synchronization & Member Distribution: Shared project tasks visible to members, assignable, toggleable, and strictly isolated from non-members', async () => {
  // 1. Register Member A (Alice, project creator)
  const aliceUname = 'alice_pm_' + Date.now();
  const regAlice = await request('POST', '/api/auth/register', {
    username: aliceUname,
    password: 'AlicePass123!',
    name: 'آلیس مدیر پروژه',
    skipVerificationForTest: true,
  });
  assert(regAlice.status === 201, 'Alice registered');
  const aliceId = regAlice.body.user.id;
  const aliceLogin = await request('POST', '/api/auth/login', { username: aliceUname, password: 'AlicePass123!' });
  const aliceHeader = { Authorization: `Bearer ${aliceLogin.body.token}` };

  // 2. Register Member B (Bob, project member)
  const bobUname = 'bob_dev_' + Date.now();
  const regBob = await request('POST', '/api/auth/register', {
    username: bobUname,
    password: 'BobPass123!',
    name: 'باب توسعه‌دهنده',
    skipVerificationForTest: true,
  });
  assert(regBob.status === 201, 'Bob registered');
  const bobId = regBob.body.user.id;
  const bobLogin = await request('POST', '/api/auth/login', { username: bobUname, password: 'BobPass123!' });
  const bobHeader = { Authorization: `Bearer ${bobLogin.body.token}` };

  // 3. Register Non-Member (Eve, outsider)
  const eveUname = 'eve_outsider_' + Date.now();
  const regEve = await request('POST', '/api/auth/register', {
    username: eveUname,
    password: 'EvePass123!',
    name: 'ایو غریبه',
    skipVerificationForTest: true,
  });
  assert(regEve.status === 201, 'Eve registered');
  const eveLogin = await request('POST', '/api/auth/login', { username: eveUname, password: 'EvePass123!' });
  const eveHeader = { Authorization: `Bearer ${eveLogin.body.token}` };

  // 4. Alice creates a Team Project with Bob as member
  const projRes = await request('POST', '/api/projects', {
    name: 'پروژه مشترک آلفا',
    description: 'توسعه ماژول جدید تیم',
    color: '#6366f1',
    icon: 'FolderKanban',
    memberIds: [bobId],
  }, aliceHeader);
  assert(projRes.status === 201, `Team project created, got ${projRes.status}`);
  const projId = projRes.body.project.id;

  // 5. Alice creates a task in this project assigned to Bob
  const task1Res = await request('POST', '/api/tasks', {
    title: 'تسک تخصیص‌یافته به باب',
    projectId: projId,
    userId: bobId,
    date: '2026-10-15',
    priority: 'high',
  }, aliceHeader);
  assert(task1Res.status === 201 || task1Res.status === 200, 'Task 1 created in project assigned to Bob');
  const task1Id = task1Res.body.task.id;

  // 6. Alice creates another task in this project assigned to Alice herself
  const task2Res = await request('POST', '/api/tasks', {
    title: 'تسک آلیس در پروژه مشترک',
    projectId: projId,
    userId: aliceId,
    date: '2026-10-15',
    priority: 'medium',
  }, aliceHeader);
  assert(task2Res.status === 201 || task2Res.status === 200, 'Task 2 created in project assigned to Alice');
  const task2Id = task2Res.body.task.id;

  // 7. Bob fetches his tasks via GET /api/tasks
  // Bob MUST receive BOTH tasks: task1 (assigned to Bob) AND task2 (assigned to Alice in project they share)
  const bobTasksRes = await request('GET', '/api/tasks', null, bobHeader);
  assert(bobTasksRes.status === 200, 'Bob fetched tasks successfully');
  const bobTaskIds = bobTasksRes.body.tasks.map((t) => t.id);
  assert(bobTaskIds.includes(task1Id), 'Bob can see task 1 assigned to him in the project');
  assert(bobTaskIds.includes(task2Id), 'Bob can see task 2 assigned to Alice in the shared project');

  // 8. Bob can toggle task 2 (which was created and assigned to Alice) because Bob is a project member!
  const toggleRes = await request('POST', '/api/tasks', { action: 'toggle', id: task2Id }, bobHeader);
  assert(toggleRes.status === 200, `Bob can toggle task in shared project, got ${toggleRes.status}`);
  assert(toggleRes.body.task?.completed === true, 'Task 2 completed status toggled to true');

  // 9. Alice fetches tasks and sees the task is now completed
  const aliceTasksRes = await request('GET', '/api/tasks', null, aliceHeader);
  const aliceTask2 = aliceTasksRes.body.tasks.find((t) => t.id === task2Id);
  assert(aliceTask2 && aliceTask2.completed === true, 'Alice sees task 2 marked as completed by Bob');

  // 10. Strict Isolation: Eve (non-member) fetches tasks and CANNOT see either project task
  const eveTasksRes = await request('GET', '/api/tasks', null, eveHeader);
  assert(eveTasksRes.status === 200, 'Eve fetched tasks');
  const eveTaskIds = eveTasksRes.body.tasks.map((t) => t.id);
  assert(!eveTaskIds.includes(task1Id), 'Eve must NOT see task 1 from private project');
  assert(!eveTaskIds.includes(task2Id), 'Eve must NOT see task 2 from private project');

  // 11. Strict Isolation: Eve tries to toggle task 1 -> 403 Forbidden
  const eveToggleRes = await request('POST', '/api/tasks', { action: 'toggle', id: task1Id }, eveHeader);
  assert(eveToggleRes.status === 403, `Eve blocked with 403 from toggling task 1, got ${eveToggleRes.status}`);
});

// Run all tests
async function run() {
  const globalDbPath = path.join(__dirname, 'data', 'db.json');
  const globalUsersPath = path.join(__dirname, 'data', 'users.json');
  const globalBackup = globalDbPath + '.suite_backup';
  const globalUsersBackup = globalUsersPath + '.suite_backup';
  if (fs.existsSync(globalDbPath)) {
    fs.copyFileSync(globalDbPath, globalBackup);
  }
  if (fs.existsSync(globalUsersPath)) {
    fs.copyFileSync(globalUsersPath, globalUsersBackup);
  }

  try {
    console.log(`Starting ${tests.length} automated integration tests...\n`);
    let passed = 0;
    let failed = 0;

    for (const t of tests) {
      try {
        await t.fn();
        console.log(`  ✓ PASS: ${t.name}`);
        passed++;
      } catch (err) {
        console.error(`  ✗ FAIL: ${t.name}`);
        console.error(`    -> ${err.message}\n`);
        failed++;
      }
    }

    console.log(`\n========================================`);
    console.log(`Results: ${passed} passed, ${failed} failed`);
    console.log(`========================================`);

    if (failed > 0) {
      process.exit(1);
    }
  } finally {
    if (fs.existsSync(globalBackup)) {
      fs.copyFileSync(globalBackup, globalDbPath);
      fs.unlinkSync(globalBackup);
    }
    if (fs.existsSync(globalUsersBackup)) {
      fs.copyFileSync(globalUsersBackup, globalUsersPath);
      fs.unlinkSync(globalUsersBackup);
    }
  }
}

run().catch((err) => {
  console.error('Fatal Test Runner Error:', err);
  process.exit(1);
});

