with open('src/components/FocusTimer.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update outer container
content = content.replace(
    'return (\n    <div className="w-full space-y-6 max-w-xl mx-auto" dir="rtl">',
    'return (\n    <div className="w-full max-w-xl mx-auto space-y-5 px-1 sm:px-0 overflow-hidden" dir="rtl">'
)

# 2. Update card padding
content = content.replace(
    '<div className="rounded-[36px] bg-white dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800 p-6 sm:p-8 shadow-xl flex flex-col items-center space-y-6 relative overflow-hidden animate-in fade-in">',
    '<div className="rounded-[32px] sm:rounded-[36px] bg-white dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800 p-4 sm:p-7 shadow-xl flex flex-col items-center space-y-5 relative overflow-hidden animate-in fade-in w-full max-w-full">'
)

# 3. Update Mode segmented control for perfect mobile fit
old_segmented = """          {/* Mode segmented control */}
          <div className="w-full flex items-center p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl border border-slate-200/80 dark:border-slate-700/60 shadow-inner z-10">
            <button
              onClick={() => handleModeChange('focus')}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'focus'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-emerald-400 shadow-sm font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>تمرکز عمیق</span>
              <span className="text-[10px] opacity-75 font-mono">({toPersianDigits(focusDurationMin)}د)</span>
            </button>

            <button
              onClick={() => handleModeChange('shortBreak')}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'shortBreak'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-amber-400 shadow-sm font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Coffee className="w-3.5 h-3.5" />
              <span>استراحت کوتاه</span>
              <span className="text-[10px] opacity-75 font-mono">({toPersianDigits(shortBreakDurationMin)}د)</span>
            </button>

            <button
              onClick={() => handleModeChange('longBreak')}
              className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'longBreak'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-purple-400 shadow-sm font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>استراحت بلند</span>
              <span className="text-[10px] opacity-75 font-mono">({toPersianDigits(longBreakDurationMin)}د)</span>
            </button>
          </div>"""

new_segmented = """          {/* Mode segmented control */}
          <div className="w-full flex items-center p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl border border-slate-200/80 dark:border-slate-700/60 shadow-inner z-10 gap-1">
            <button
              onClick={() => handleModeChange('focus')}
              className={`flex-1 py-2 px-1 text-[11px] sm:text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
                mode === 'focus'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-emerald-400 shadow-sm font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>تمرکز<span className="hidden sm:inline"> عمیق</span></span>
              <span className="text-[10px] opacity-75 font-mono">({toPersianDigits(focusDurationMin)}د)</span>
            </button>

            <button
              onClick={() => handleModeChange('shortBreak')}
              className={`flex-1 py-2 px-1 text-[11px] sm:text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
                mode === 'shortBreak'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-amber-400 shadow-sm font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Coffee className="w-3 h-3 flex-shrink-0" />
              <span>استراحت<span className="hidden sm:inline"> کوتاه</span></span>
              <span className="text-[10px] opacity-75 font-mono">({toPersianDigits(shortBreakDurationMin)}د)</span>
            </button>

            <button
              onClick={() => handleModeChange('longBreak')}
              className={`flex-1 py-2 px-1 text-[11px] sm:text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
                mode === 'longBreak'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-purple-400 shadow-sm font-black'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span><span className="hidden sm:inline">استراحت </span>بلند</span>
              <span className="text-[10px] opacity-75 font-mono">({toPersianDigits(longBreakDurationMin)}د)</span>
            </button>
          </div>"""

assert old_segmented in content
content = content.replace(old_segmented, new_segmented, 1)

# 4. Update preset chips for better responsiveness
old_presets = """            {/* Presets Chips */}
            {mode === 'focus' ? (
              <div className="flex items-center justify-center gap-1.5 flex-wrap">
                {[15, 20, 25, 30, 45, 60].map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setCustomFocusMinutes(mins)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      focusDurationMin === mins
                        ? 'bg-emerald-600 text-white shadow-xs font-black ring-2 ring-emerald-400/40'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    {toPersianDigits(mins)} دقیقه
                  </button>
                ))}
              </div>
            ) : ("""

new_presets = """            {/* Presets Chips */}
            {mode === 'focus' ? (
              <div className="flex items-center justify-center gap-1 sm:gap-1.5 flex-wrap w-full">
                {[15, 20, 25, 30, 45, 60].map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setCustomFocusMinutes(mins)}
                    className={`px-2.5 sm:px-3 py-1 rounded-xl text-[11px] sm:text-xs font-bold transition-all cursor-pointer ${
                      focusDurationMin === mins
                        ? 'bg-emerald-600 text-white shadow-xs font-black ring-2 ring-emerald-400/40'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    {toPersianDigits(mins)} د
                  </button>
                ))}
              </div>
            ) : ("""

assert old_presets in content
content = content.replace(old_presets, new_presets, 1)

with open('src/components/FocusTimer.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('FocusTimer.tsx updated!')
