with open('src/components/InstagramSlidesStudio.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace renderFeatureMockupCard with photorealistic renderer
p_start = content.find("  // Feature Screenshot Mockup Card")
p_end = content.find("  // Render Story Content (Identical for Preview & 4K Export)")
assert p_start != -1 and p_end != -1, "Mockup card boundaries found"

new_mockup_block = '''  // Feature Screenshot Mockup Card (Photorealistic Bag Time UI)
  const renderFeatureMockupCard = (cycleIdx: number, isLight: boolean) => {
    const windowHeader = (title: string, url: string) => (
      <div className="px-3 py-1.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-[9px]">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-rose-500" />
          <span className="w-2 h-2 rounded-full bg-amber-500" />
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
        </div>
        <div className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono text-[8px] flex items-center gap-1" dir="ltr">
          <span className="text-emerald-400">🔒</span>
          <span>{url}</span>
        </div>
        <span className="text-slate-300 font-bold text-[8.5px]">{title}</span>
      </div>
    );

    let innerContent = null;
    if (cycleIdx === 0) {
      // 1. Photorealistic Hourly Planner
      innerContent = (
        <div className="p-2.5 bg-[#0b0f19] text-white space-y-1.5 text-right font-sans">
          <div className="flex items-center justify-between text-[9px] pb-1 border-b border-slate-800">
            <span className="font-black text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>دیلی پلنر ساعتی بگ‌تایم</span>
            </span>
            <span className="text-slate-400 text-[8px]">چهارشنبه • امروز</span>
          </div>

          <div className="space-y-1 text-[9px]">
            <div className="p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded-md bg-emerald-500 text-white flex items-center justify-center text-[8px] font-black">✓</span>
                <span className="line-through text-slate-400 font-bold">جلسه اول صبح و بررسی تسک‌ها</span>
              </div>
              <span className="text-[8px] text-slate-500 font-mono">۰۹:۰۰</span>
            </div>

            <div className="relative p-2 rounded-xl bg-gradient-to-r from-emerald-950/80 to-slate-900 border-r-4 border-emerald-500 border border-emerald-800/60 shadow-lg">
              <div className="flex items-center justify-between mb-0.5">
                <span className="font-black text-white text-[9.5px]">کار عمیق روی توسعه فیچر اصلی</span>
                <span className="px-1.5 py-0.2 rounded bg-rose-500 text-white text-[7.5px] font-black animate-pulse">هم‌اکنون</span>
              </div>
              <div className="flex items-center justify-between text-[8px] text-emerald-300">
                <span>⏱️ ۲۵ دقیقه تمرکز پیوسته</span>
                <span className="font-mono">۱۰:۰۰ - ۱۱:۳۰</span>
              </div>
            </div>

            <div className="p-1.5 rounded-xl bg-slate-900/70 border border-slate-800/80 flex items-center justify-between opacity-80">
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded-md border border-slate-700 bg-slate-800" />
                <span className="text-slate-300 font-bold">بررسی پیام‌ها و هماهنگی تیمی</span>
              </div>
              <span className="text-[8px] text-slate-500 font-mono">۱۱:۳۰</span>
            </div>
          </div>
        </div>
      );
    } else if (cycleIdx === 1) {
      // 2. Photorealistic AI Habits Analyzer
      innerContent = (
        <div className="p-2.5 bg-[#0b0f19] text-white space-y-1.5 text-right font-sans">
          <div className="flex items-center justify-between text-[9px] pb-1 border-b border-slate-800">
            <span className="font-black text-purple-400">تحلیلگر هوشمند عادات (AI Habits)</span>
            <span className="text-slate-400 text-[8px]">آمار هفتگی</span>
          </div>

          <div className="grid grid-cols-2 gap-1.5 text-center">
            <div className="p-1.5 rounded-xl bg-purple-500/10 border border-purple-500/30">
              <div className="text-base font-black text-purple-300 font-mono">۸۸٪</div>
              <div className="text-[8px] text-slate-400">بهره‌وری هفتگی</div>
            </div>
            <div className="p-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
              <div className="text-base font-black text-emerald-300 font-mono">۴.۲ ساعت</div>
              <div className="text-[8px] text-slate-400">تمرکز عمیق روزانه</div>
            </div>
          </div>

          <div className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-[8px] space-y-0.5">
            <div className="text-slate-300 font-bold">⚠️ موانع اصلی شناسایی‌شده:</div>
            <div className="flex justify-between text-slate-400">
              <span>۱. حواس‌پرتی با گوشی هوشمند</span>
              <span className="text-rose-400 font-bold">۳۴٪</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>۲. افت انرژی بعد از ناهار</span>
              <span className="text-amber-400 font-bold">۲۲٪</span>
            </div>
          </div>
        </div>
      );
    } else if (cycleIdx === 2) {
      // 3. Photorealistic New Tab Extension
      innerContent = (
        <div className="p-2.5 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 text-white space-y-1.5 text-center font-sans">
          <div className="text-lg font-black font-mono text-slate-100 tracking-wider">
            ۱۰:۴۵
          </div>
          <div className="text-[8px] text-emerald-400 font-bold">
            «موفقیت تکرار مداوم عادت‌های کوچک است»
          </div>

          <div className="p-1.5 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-between text-[8px] text-slate-400 px-2">
            <span>جستجو در گوگل یا وارد کردن آدرس وب...</span>
            <span>🔍</span>
          </div>

          <div className="grid grid-cols-4 gap-1 text-[8px] font-bold">
            <div className="p-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-200">📊 تسک‌ها</div>
            <div className="p-1 rounded-lg bg-slate-800 border border-slate-700 text-emerald-400">🎧 پومودورو</div>
            <div className="p-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-200">💬 بله</div>
            <div className="p-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-200">🌐 نگاه</div>
          </div>
        </div>
      );
    } else if (cycleIdx === 3) {
      // 4. Photorealistic Focus Room
      innerContent = (
        <div className="p-2.5 bg-[#0b0f19] text-white space-y-1.5 text-right font-sans">
          <div className="flex items-center justify-between text-[9px] pb-1 border-b border-slate-800">
            <span className="font-black text-amber-400">اتاق تمرکز زنده (دیپ ورک تیمی)</span>
            <span className="text-emerald-400 font-bold text-[8px] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>۵ نفر آنلاین</span>
            </span>
          </div>

          <div className="p-2 rounded-2xl bg-slate-900 border border-amber-500/30 flex items-center justify-between">
            <div>
              <div className="text-xl font-black font-mono text-white tracking-wider">۲۴:۵۲</div>
              <div className="text-[8px] text-amber-300 font-bold">هدف: تکمیل کدها و تست سامانه</div>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-xl">🎧</span>
              <span className="text-[7px] text-slate-400">موزیک لوفای</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-[8px] text-slate-400">
            <span>همکاران حاضر در اتاق:</span>
            <span className="text-slate-200 font-bold">محمد (میزبان)، سارا، علی و ۲ نفر دیگر</span>
          </div>
        </div>
      );
    } else {
      // 5. Photorealistic Bale Login / Dashboard
      innerContent = (
        <div className="p-2.5 bg-[#0b0f19] text-white space-y-1.5 text-right font-sans">
          <div className="flex items-center justify-between text-[9px] pb-1 border-b border-slate-800">
            <span className="font-black text-emerald-400">ربات هوشمند بَگ‌تایم در بله</span>
            <span className="text-slate-400 text-[8px]">ورود امن بدون رمز</span>
          </div>

          <div className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-[8px] text-slate-300 leading-relaxed">
            سلام! جهت ورود سریع به پنل، دکمه زیر را لمس کنید:
          </div>

          <div className="p-1.5 rounded-xl bg-emerald-600 text-white font-black text-center text-[9px] shadow-md">
            📲 اشتراک‌گذاری شماره و ورود مستقیم
          </div>

          <div className="text-center text-[7.5px] text-emerald-400 font-bold">
            ✓ تأیید آنی شماره تماس با پروتکل امن بله
          </div>
        </div>
      );
    }

    return (
      <div className="rounded-2xl border border-slate-700/80 overflow-hidden shadow-2xl bg-slate-950 my-1">
        {windowHeader('بَگ‌تایم • BagTime', 'task.mohusyn.ir')}
        {innerContent}
      </div>
    );
  };
'''

content = content[:p_start] + new_mockup_block + content[p_end:]

# Ensure await document.fonts.ready in handleExportStoryImage
font_ready_check = '''    try {
      await new Promise((r) => setTimeout(r, 60));
      if (typeof document !== 'undefined' && (document as any).fonts) {
        try {
          await (document as any).fonts.ready;
        } catch {}
      }'''

content = content.replace(
    '''    try {
      await new Promise((r) => setTimeout(r, 60));''',
    font_ready_check
)

with open('src/components/InstagramSlidesStudio.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('InstagramSlidesStudio photorealistic mockups updated successfully!')
