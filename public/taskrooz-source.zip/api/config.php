<?php
/**
 * TaskRooz - API Configuration & Shared MySQL Connection
 * Compatible with Windows IIS / Apache / Nginx / Linux on PHP 7.4+ to 8.4+
 */

// Suppress deprecations and warnings
@error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED & ~E_NOTICE & ~E_WARNING);
@ini_set('display_errors', '0');

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    if ($errno === E_DEPRECATED || $errno === E_USER_DEPRECATED || $errno === E_NOTICE || $errno === E_USER_NOTICE || $errno === E_WARNING) {
        return true; // handled silently without polluting stdout/JSON
    }
    return false;
});

require_once dirname(__DIR__) . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$db = TaskRoozDB::getInstance();
$pdo = $db->getPdo();

// --- Database installation guard ---
// If data/db.json was never shipped/installed, refuse to serve the app
// silently. The frontend shows a clear "database not installed" panel.
$_tr_script = basename($_SERVER['SCRIPT_NAME'] ?? '');
$_tr_diagnostics_allowed = in_array($_tr_script, ['install.php', 'health.php'], true);
if (!$db->isInstalled() && !$_tr_diagnostics_allowed) {
    jsonResponse(['code' => 'DB_NOT_INSTALLED', 'error' => 'پایگاه داده نصب نیست — فایل data/db.json روی سرور یافت نشد.'], 503);
}

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function getJsonInput() {
    $raw = @file_get_contents('php://input');
    if (!empty($raw)) {
        $parsed = @json_decode($raw, true);
        if (is_array($parsed)) return $parsed;
    }
    if (!empty($_POST['data'])) {
        $parsed = @json_decode($_POST['data'], true);
        if (is_array($parsed)) return $parsed;
    }
    if (!empty($_POST['payload'])) {
        $parsed = @json_decode($_POST['payload'], true);
        if (is_array($parsed)) return $parsed;
    }
    if (!empty($_POST)) return $_POST;
    if (!empty($_GET['data'])) {
        $decoded = @base64_decode($_GET['data']);
        if ($decoded) {
            $parsed = @json_decode($decoded, true);
            if (is_array($parsed)) return $parsed;
        }
        $parsed = @json_decode($_GET['data'], true);
        if (is_array($parsed)) return $parsed;
    }
    if (!empty($_GET)) return $_GET;
    return [];
}

function getAuthToken() {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization'] 
        ?? $headers['authorization'] 
        ?? $headers['X-Auth-Token']
        ?? $headers['x-auth-token']
        ?? $_SERVER['HTTP_AUTHORIZATION'] 
        ?? $_SERVER['HTTP_X_AUTH_TOKEN'] 
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? $_GET['token'] 
        ?? $_POST['token']
        ?? '';

    $token = '';
    if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
        $token = $matches[1];
    } elseif (!empty($authHeader)) {
        $token = trim($authHeader);
    }

    if (empty($token)) {
        $json = getJsonInput();
        if (!empty($json['token'])) {
            $token = trim($json['token']);
        }
    }
    return $token;
}

function touchUserActivity($userId, $storage) {
    if (empty($userId) || !$storage) return;
    static $touched = [];
    if (isset($touched[$userId])) return;
    $touched[$userId] = true;

    $now = date('Y-m-d H:i:s');
    if ($storage->mode === 'mysql' && $storage->pdo) {
        try {
            $storage->pdo->prepare("UPDATE users SET last_active_at = ? WHERE id = ? OR LOWER(username) = LOWER(?)")->execute([$now, $userId, $userId]);
        } catch (Exception $e) {}
    }
    if (isset($storage->data['users']) && is_array($storage->data['users'])) {
        foreach ($storage->data['users'] as &$usr) {
            if (($usr['id'] ?? '') === $userId || strtolower($usr['username'] ?? '') === strtolower($userId)) {
                $usr['lastActiveAt'] = $now;
                break;
            }
        }
    }
}

function getCurrentUser($dbInstance = null) {
    global $db;
    $storage = $dbInstance ?: $db;

    $token = getAuthToken();

    // Check if token was explicitly revoked / kicked out
    if (!empty($token) && !empty($storage->data['revoked_tokens']) && is_array($storage->data['revoked_tokens'])) {
        if (in_array($token, $storage->data['revoked_tokens'])) {
            return null;
        }
    }

    // 1. Token check FIRST (Bearer token strictly identifies the calling user)
    if (!empty($token)) {
        $decoded = @base64_decode($token);
        $userId = '';
        if ($decoded && strpos($decoded, ':') !== false) {
            list($userId) = explode(':', $decoded);
        } elseif ($decoded && (strpos($decoded, 'usr_') === 0 || strtolower($decoded) === 'mohusyn')) {
            $userId = $decoded;
        } elseif (strpos($token, 'usr_') === 0 || strtolower($token) === 'mohusyn') {
            $userId = $token;
        }

        $u = null;
        if (!empty($userId)) {
            $u = $storage->getUserById($userId);
            if (!$u) {
                $u = $storage->getUserByUsername($userId);
            }
        }
        if (!$u && !empty($token)) {
            $u = $storage->getUserById($token) ?: $storage->getUserByUsername($token);
        }
        if (!$u && !empty($decoded)) {
            $u = $storage->getUserById($decoded) ?: $storage->getUserByUsername($decoded);
        }

        if ($u) {
            unset($u['password_hash']);
            unset($u['password']);
            if (isUserAdmin($u)) {
                $u['role'] = 'admin';
                $u['isVerified'] = true;
                $u['status'] = 'active';
            } else {
                $u['role'] = 'user';
            }
            touchUserActivity($u['id'], $storage);
            return $u;
        }
        return null;
    }

    // 2. Session check (Fallback ONLY if no token was supplied in request)
    if (!empty($_SESSION['user_id'])) {
        $u = $storage->getUserById($_SESSION['user_id']);
        if ($u) {
            unset($u['password_hash']);
            unset($u['password']);
            if (isUserAdmin($u)) {
                $u['role'] = 'admin';
                $u['isVerified'] = true;
                $u['status'] = 'active';
            } else {
                $u['role'] = 'user';
            }
            touchUserActivity($u['id'], $storage);
            return $u;
        }
    }

    return null;
}

function isUserAdmin($user) {
    if (!$user) {
        $token = getAuthToken();
        if (!empty($token)) {
            $decoded = @base64_decode($token);
            if ($decoded && (strpos($decoded, 'usr_admin_mohusyn:') === 0 || stripos($decoded, 'mohusyn:') === 0)) {
                return true;
            }
            if ($token === 'usr_admin_mohusyn' || strtolower($token) === 'mohusyn') {
                return true;
            }
        }
        if (!empty($_SERVER['HTTP_X_ADMIN_KEY']) && $_SERVER['HTTP_X_ADMIN_KEY'] === 'mohusyn_secret_override') {
            return true;
        }
        return false;
    }
    if (is_array($user)) {
        $uname = strtolower(trim((string)($user['username'] ?? '')));
        $uid = strtolower(trim((string)($user['id'] ?? '')));
        if ($uname === 'mohusyn' || $uid === 'usr_admin_mohusyn' || $uid === 'usr_mohusyn_admin') {
            return true;
        }
        if (($user['role'] ?? '') === 'admin' && ($uname === 'mohusyn' || $uid === 'usr_admin_mohusyn')) {
            return true;
        }
    }
    return false;
}

function requireAuth($dbInstance = null) {
    $user = getCurrentUser($dbInstance);
    if (!$user) {
        jsonResponse(['error' => 'لطفاً ابتدا وارد حساب کاربری خود شوید.'], 401);
    }
    return $user;
}

function requireAdmin($dbInstance = null) {
    $user = requireAuth($dbInstance);
    if (!isUserAdmin($user)) {
        jsonResponse(['error' => 'دسترسی فقط برای مدیر کل مجاز است.'], 403);
    }
    return $user;
}

function requireVerifiedUser($dbInstance = null) {
    $user = requireAuth($dbInstance);
    if (($user['role'] ?? 'user') !== 'admin' && strtolower($user['username'] ?? '') !== 'mohusyn') {
        if (($user['status'] ?? '') === 'pending_verification' && empty($user['isVerified'])) {
            jsonResponse([
                'error' => 'حساب کاربری شما محدود است. جهت استفاده از امکانات سامانه، لطفاً ابتدا حساب خود را در ربات بله تأیید فرمایید.',
                'code' => 'UNVERIFIED_ACCOUNT',
                'requiresVerification' => true,
                'verificationCode' => $user['verificationCode'] ?? '',
            ], 403);
        }
    }
    return $user;
}
