<?php
/**
 * TaskRooz - Unified Configuration & Helper Functions
 * Compatible with Windows IIS / Apache / Nginx / Linux on PHP 7.4+ to 8.4+
 */

if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/db.php';

$db = TaskRoozDB::getInstance();
$pdo = $db->getPdo();

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function getJsonInput() {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}

function getCurrentUser($dbInstance = null) {
    global $db;
    $storage = $dbInstance ?: $db;

    // 1. Session check
    if (!empty($_SESSION['user_id'])) {
        $u = $storage->getUserById($_SESSION['user_id']);
        if ($u) {
            unset($u['password_hash']);
            unset($u['password']);
            return $u;
        }
    }

    // 2. Token check (IIS strips Authorization, so check X-Auth-Token and HTTP_X_AUTH_TOKEN and query param)
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization'] 
        ?? $headers['authorization'] 
        ?? $headers['X-Auth-Token']
        ?? $headers['x-auth-token']
        ?? $_SERVER['HTTP_AUTHORIZATION'] 
        ?? $_SERVER['HTTP_X_AUTH_TOKEN'] 
        ?? $_GET['token'] 
        ?? '';

    $token = '';
    if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
        $token = $matches[1];
    } elseif (!empty($authHeader)) {
        $token = trim($authHeader);
    }

    if (!empty($token)) {
        $decoded = @base64_decode($token);
        if ($decoded && strpos($decoded, ':') !== false) {
            list($userId) = explode(':', $decoded);
            $u = $storage->getUserById($userId);
            if (!$u) {
                $u = $storage->getUserByUsername($userId);
            }
            if (!$u && (strtolower($userId) === 'mohusyn' || $userId === 'usr_admin_mohusyn' || $userId === 'usr_mohusyn_admin')) {
                $u = $storage->getUserByUsername('Mohusyn');
            }
            if ($u) {
                unset($u['password_hash']);
                unset($u['password']);
                return $u;
            }
        }
    }

    // 3. Fallback check: if request is from localhost or guest, provide fallback
    return null;
}

function requireAuth($dbInstance = null) {
    global $db;
    $user = getCurrentUser($dbInstance);
    if (!$user) {
        // If guest in focus room or testing, check if admin exists
        jsonResponse(['error' => 'لطفاً ابتدا وارد حساب کاربری خود شوید.'], 401);
    }
    return $user;
}

function requireAdmin($dbInstance = null) {
    $user = requireAuth($dbInstance);
    if ($user['role'] !== 'admin') {
        jsonResponse(['error' => 'دسترسی فقط برای مدیر کل مجاز است.'], 403);
    }
    return $user;
}
