# 1. InstagramSlidesStudio.tsx
with open('src/components/InstagramSlidesStudio.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("  Camera,\n  Trash2,\n", "  Camera,\n  Trash2,\n  Smartphone,\n")
with open('src/components/InstagramSlidesStudio.tsx', 'w', encoding='utf-8') as f:
    f.write(text)

# 2. AppTutorialStudio.tsx
with open('src/components/AppTutorialStudio.tsx', 'r', encoding='utf-8') as f:
    text2 = f.read()
text2 = text2.replace("import { useTask } from '../context/TaskContext';\n", "")
with open('src/components/AppTutorialStudio.tsx', 'w', encoding='utf-8') as f:
    f.write(text2)

print("Imports cleaned!")
