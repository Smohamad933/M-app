with open('src/components/InstagramSlidesStudio.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add import
content = content.replace(
    "import { FontSelectorModal } from './FontSelectorModal';",
    "import { FontSelectorModal } from './FontSelectorModal';\nimport { AppTutorialStudio } from './AppTutorialStudio';"
)

# 2. Update type
content = content.replace(
    "type StudioTab = 'feed_posts' | 'stories_strategy';",
    "type StudioTab = 'feed_posts' | 'stories_strategy' | 'app_tutorial';"
)

# 3. Add Tab Button in top navbar
old_nav_buttons = """          <button
            type="button"
            onClick={() => setActiveTab('stories_strategy')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'stories_strategy'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>تقویم ۶۰ روزه استوری‌ها</span>
          </button>
        </div>"""

new_nav_buttons = """          <button
            type="button"
            onClick={() => setActiveTab('stories_strategy')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'stories_strategy'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>تقویم ۶۰ روزه استوری‌ها</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('app_tutorial')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'app_tutorial'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>📱 استودیو آموزش کامل اپ (پست + استوری)</span>
          </button>
        </div>"""

assert old_nav_buttons in content
content = content.replace(old_nav_buttons, new_nav_buttons, 1)

# 4. Render AppTutorialStudio when activeTab === 'app_tutorial'
target_end_story_tab = """              <button
                type="button"
                onClick={handleExportStoryImage}
                disabled={isExporting}
                className="px-5 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs transition-all flex items-center gap-2 shadow-lg cursor-pointer disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                <span>دانلود استوری {exportQuality === '4k' ? 'با کیفیت 4K' : '۱۰۸۰p'} (PNG)</span>
              </button>
            </div>
          </div>
        </div>
      )}"""

tutorial_tab_render = """              <button
                type="button"
                onClick={handleExportStoryImage}
                disabled={isExporting}
                className="px-5 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs transition-all flex items-center gap-2 shadow-lg cursor-pointer disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                <span>دانلود استوری {exportQuality === '4k' ? 'با کیفیت 4K' : '۱۰۸۰p'} (PNG)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── TAB 3: DEDICATED APP TUTORIAL POST & STORY STUDIO ── */}
      {activeTab === 'app_tutorial' && (
        <AppTutorialStudio />
      )}"""

assert target_end_story_tab in content
content = content.replace(target_end_story_tab, tutorial_tab_render, 1)

with open('src/components/InstagramSlidesStudio.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('InstagramSlidesStudio.tsx updated with AppTutorialStudio!')
