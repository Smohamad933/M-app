with open('src/components/MainLayout.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update Header Container to prevent horizontal overflow
old_header = '<header className="bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 py-2.5 sm:py-3.5 sticky top-0 z-20 flex-shrink-0 flex flex-col gap-2">'
new_header = '<header className="bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-3 sm:px-6 py-2 sm:py-3 sticky top-0 z-20 flex-shrink-0 flex flex-col gap-2 max-w-full overflow-hidden">'
assert old_header in content
content = content.replace(old_header, new_header, 1)

# 2. Hide cluttered buttons on mobile / small screens
# 2.1 Admin select
old_admin_select = '<select\n                    value={currentUser.id}\n                    onChange={(e) => handleSwitchUser(e.target.value)}\n                    className="text-xs bg-slate-50 border border-slate-200 rounded-full px-2.5 py-1 text-slate-700 font-bold outline-none cursor-pointer hidden md:block max-w-[130px] truncate"'
new_admin_select = '<select\n                    value={currentUser.id}\n                    onChange={(e) => handleSwitchUser(e.target.value)}\n                    className="text-xs bg-slate-50 border border-slate-200 rounded-full px-2.5 py-1 text-slate-700 font-bold outline-none cursor-pointer hidden xl:block max-w-[130px] truncate"'
if old_admin_select in content:
    content = content.replace(old_admin_select, new_admin_select, 1)

# 2.2 Extension button
old_ext_btn = """                {/* Browser Extension Assistant Button */}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playPop();
                    setIsExtensionModalOpen(true);
                  }}
                  className="h-8 sm:h-9 px-2.5 sm:px-3 rounded-full border border-indigo-200 bg-indigo-50/80 hover:bg-indigo-100 flex items-center gap-1.5 text-indigo-700 font-bold text-xs transition-colors shadow-2xs cursor-pointer flex-shrink-0"
                  title="افزونه دستیار نیوتَب مرورگر (کروم، اج، فایرفاکس)"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                  <span className="hidden sm:inline">افزونه دستیار</span>
                </button>"""

new_ext_btn = """                {/* Browser Extension Assistant Button */}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playPop();
                    setIsExtensionModalOpen(true);
                  }}
                  className="h-8 sm:h-9 px-2.5 sm:px-3 rounded-full border border-indigo-200 bg-indigo-50/80 hover:bg-indigo-100 items-center gap-1.5 text-indigo-700 font-bold text-xs transition-colors shadow-2xs cursor-pointer flex-shrink-0 hidden lg:flex"
                  title="افزونه دستیار نیوتَب مرورگر (کروم، اج، فایرفاکس)"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                  <span>افزونه دستیار</span>
                </button>"""
assert old_ext_btn in content
content = content.replace(old_ext_btn, new_ext_btn, 1)

# 2.3 Instagram Studio Button
old_insta_btn = """                {/* Instagram Carousel Studio Button - ONLY FOR SUPER ADMIN */}
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playPop();
                      if (onOpenInstagramStudio) {
                        onOpenInstagramStudio();
                      } else {
                        const url = new URL(window.location.href);
                        url.searchParams.set('page', 'instagram');
                        window.location.href = url.toString();
                      }
                    }}
                    className="h-8 sm:h-9 px-2.5 sm:px-3 rounded-full border border-pink-200 bg-pink-50/80 hover:bg-pink-100 flex items-center gap-1.5 text-pink-700 font-bold text-xs transition-colors shadow-2xs cursor-pointer flex-shrink-0"
                    title="استودیو ساخت اسلایدهای گرافیکی اینستاگرام (مخصوص مدیر کل)"
                  >
                    <span className="text-xs">📸</span>
                    <span className="hidden md:inline">اسلایدهای اینستاگرام</span>
                  </button>
                )}"""

new_insta_btn = """                {/* Instagram Carousel Studio Button - ONLY FOR SUPER ADMIN (hidden on mobile) */}
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playPop();
                      if (onOpenInstagramStudio) {
                        onOpenInstagramStudio();
                      } else {
                        const url = new URL(window.location.href);
                        url.searchParams.set('page', 'instagram');
                        window.location.href = url.toString();
                      }
                    }}
                    className="h-8 sm:h-9 px-2.5 sm:px-3 rounded-full border border-pink-200 bg-pink-50/80 hover:bg-pink-100 items-center gap-1.5 text-pink-700 font-bold text-xs transition-colors shadow-2xs cursor-pointer flex-shrink-0 hidden lg:flex"
                    title="استودیو ساخت اسلایدهای گرافیکی اینستاگرام (مخصوص مدیر کل)"
                  >
                    <span className="text-xs">📸</span>
                    <span>اسلایدهای اینستاگرام</span>
                  </button>
                )}"""
assert old_insta_btn in content
content = content.replace(old_insta_btn, new_insta_btn, 1)

# 2.4 Dark/Light Mode Switcher: hide on mobile (< md)
old_dark_btn = """                {/* Dark / Light Mode Switcher */}
                <button
                  type="button"
                  onClick={toggleThemeMode}
                  className={`w-8 sm:w-9 h-8 sm:h-9 rounded-full border flex items-center justify-center transition-all shadow-2xs cursor-pointer flex-shrink-0 ${
                    themeMode === 'dark'
                      ? 'border-amber-500/40 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20'
                      : 'border-slate-200/80 bg-white text-slate-600 hover:bg-slate-100'
                  }`}
                  title={themeMode === 'dark' ? 'تغییر به تم روشن (Light)' : 'تغییر به تم تاریک (Dark Mode)'}
                >
                  {themeMode === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
                </button>"""

new_dark_btn = """                {/* Dark / Light Mode Switcher (hidden on mobile, set via profile/settings) */}
                <button
                  type="button"
                  onClick={toggleThemeMode}
                  className={`w-8 sm:w-9 h-8 sm:h-9 rounded-full border items-center justify-center transition-all shadow-2xs cursor-pointer flex-shrink-0 hidden md:flex ${
                    themeMode === 'dark'
                      ? 'border-amber-500/40 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20'
                      : 'border-slate-200/80 bg-white text-slate-600 hover:bg-slate-100'
                  }`}
                  title={themeMode === 'dark' ? 'تغییر به تم روشن (Light)' : 'تغییر به تم تاریک (Dark Mode)'}
                >
                  {themeMode === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
                </button>"""
assert old_dark_btn in content
content = content.replace(old_dark_btn, new_dark_btn, 1)

# 2.5 Calendar Switcher: hide on mobile (< md)
old_cal_btn = """                {/* Calendar Type Switcher (Jalali vs Gregorian) */}
                <button
                  type="button"
                  onClick={toggleCalendarType}
                  className="h-8 sm:h-9 px-2.5 rounded-full border border-slate-200/80 bg-white hover:bg-slate-100 text-slate-700 flex items-center gap-1 font-bold text-xs transition-colors shadow-2xs cursor-pointer flex-shrink-0"
                  title={calendarType === 'jalali' ? 'تقویم خورشیدی (شمسی) فعال است — کلیک برای تغییر به میلادی' : 'تقویم میلادی فعال است — کلیک برای تغییر به شمسی'}
                >
                  <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                  <span className="hidden sm:inline">{calendarType === 'jalali' ? 'تقویم شمسی' : 'تقویم میلادی'}</span>
                  <span className="sm:hidden">{calendarType === 'jalali' ? 'شمسی' : 'میلادی'}</span>
                </button>"""

new_cal_btn = """                {/* Calendar Type Switcher (hidden on mobile, set via profile/settings) */}
                <button
                  type="button"
                  onClick={toggleCalendarType}
                  className="h-8 sm:h-9 px-2.5 rounded-full border border-slate-200/80 bg-white hover:bg-slate-100 text-slate-700 items-center gap-1 font-bold text-xs transition-colors shadow-2xs cursor-pointer flex-shrink-0 hidden md:flex"
                  title={calendarType === 'jalali' ? 'تقویم خورشیدی (شمسی) فعال است — کلیک برای تغییر به میلادی' : 'تقویم میلادی فعال است — کلیک برای تغییر به شمسی'}
                >
                  <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                  <span>{calendarType === 'jalali' ? 'شمسی' : 'میلادی'}</span>
                </button>"""
assert old_cal_btn in content
content = content.replace(old_cal_btn, new_cal_btn, 1)

# 2.6 Hide Pro/Admin badge on mobile (< sm)
old_sub_badge = """                {/* Subscription Pro Badge or Upgrade Button */}
                {isPro ? (
                  <SubscriptionBadge user={currentUser} size="sm" />
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playPop();
                      setIsUpgradeModalOpen(true);
                    }}
                    className="flex items-center gap-1 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-[10px] sm:text-[11px] shadow-sm transition-all active:scale-95 cursor-pointer flex-shrink-0"
                    title="ارتقاء به اشتراک ویژه نامحدود"
                  >
                    <Sparkles className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                    <span>ارتقاء Pro</span>
                  </button>
                )}"""

new_sub_badge = """                {/* Subscription Pro Badge or Upgrade Button (hidden on mobile) */}
                <div className="hidden sm:flex items-center flex-shrink-0">
                  {isPro ? (
                    <SubscriptionBadge user={currentUser} size="sm" />
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        sounds.playPop();
                        setIsUpgradeModalOpen(true);
                      }}
                      className="flex items-center gap-1 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-[10px] sm:text-[11px] shadow-sm transition-all active:scale-95 cursor-pointer"
                      title="ارتقاء به اشتراک ویژه نامحدود"
                    >
                      <Sparkles className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                      <span>ارتقاء Pro</span>
                    </button>
                  )}
                </div>"""
assert old_sub_badge in content
content = content.replace(old_sub_badge, new_sub_badge, 1)

# 2.7 REMOVE Interface Mode Quick Switcher Pill completely from top header
old_interface_pill = """                {/* Interface Mode Quick Switcher Pill (Simple vs Advanced) */}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playPop();
                    setInterfaceMode(interfaceMode === 'simple' ? 'advanced' : 'simple');
                  }}
                  className={`h-8 sm:h-9 px-2.5 sm:px-3 rounded-full border flex items-center gap-1.5 font-bold text-xs transition-all shadow-2xs cursor-pointer flex-shrink-0 ${
                    interfaceMode === 'simple'
                      ? 'border-emerald-300/80 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                      : 'border-indigo-300/80 bg-indigo-50 text-indigo-800 hover:bg-indigo-100'
                  }`}
                  title={interfaceMode === 'simple' ? 'حالت آسان فعال است — کلیک کنید تا حالت پیشرفته و حرفه‌ای فعال شود' : 'حالت حرفه‌ای فعال است — کلیک کنید تا حالت آسان فعال شود'}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="hidden sm:inline">{interfaceMode === 'simple' ? 'رابط آسان 🌿' : 'رابط حرفه‌ای ⚡'}</span>
                  <span className="sm:hidden">{interfaceMode === 'simple' ? 'آسان' : 'Pro'}</span>
                </button>"""

if old_interface_pill in content:
    content = content.replace(old_interface_pill, "", 1)

# 3. REMOVE the green "کاربری آسان" banner from dashboard
old_dashboard_banner = """                {/* Simple Mode Friendly Quick Actions Card */}
                {interfaceMode === 'simple' && (
                  <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in">
                    <div className="space-y-1 text-right">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-lg bg-emerald-600 text-white font-bold text-[11px]">🌿 کاربری آسان</span>
                        <h2 className="text-sm font-black text-slate-900">امروز می‌خواهید چه کاری انجام دهید؟</h2>
                      </div>
                      <p className="text-xs text-slate-600">
                        سامانه در حالت آسان و بدون پیچیدگی است. تسک جدید بنویسید یا زمان‌سنج تمرکز را استارت بزنید:
                      </p>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        onClick={() => openCreateModal(selectedDate)}
                        className="px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>ثبت سریع تسک</span>
                      </button>

                      <button
                        onClick={() => setActiveTab('focus')}
                        className="px-4 py-2.5 rounded-2xl bg-slate-900 hover:bg-black text-white font-black text-xs shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Timer className="w-4 h-4 text-emerald-400" />
                        <span>شروع تمرکز</span>
                      </button>
                    </div>
                  </div>
                )}"""

if old_dashboard_banner in content:
    content = content.replace(old_dashboard_banner, "", 1)

# 4. Update NotificationCenterModal usage so clicking a notification opens direct chat immediately
old_notif_modal = """      {/* Notification Center Modal */}
      <NotificationCenterModal
        isOpen={isNotificationCenterOpen}
        onClose={() => setIsNotificationCenterOpen(false)}
        notifications={notifications}
        onMarkAllAsRead={handleMarkAllNotifsRead}
        onClearAll={handleClearAllNotifs}
        onOpenTask={(_taskId) => {
          setActiveTab('tasks');
        }}
        onOpenChat={(userId, userName) => {
          setDirectChatUser({ id: userId, name: userName, status: 'online' });
        }}
      />"""

new_notif_modal = """      {/* Notification Center Modal */}
      <NotificationCenterModal
        isOpen={isNotificationCenterOpen}
        onClose={() => setIsNotificationCenterOpen(false)}
        notifications={notifications}
        onMarkAllAsRead={handleMarkAllNotifsRead}
        onClearAll={handleClearAllNotifs}
        onOpenTask={(_taskId) => {
          setActiveTab('tasks');
          setIsNotificationCenterOpen(false);
        }}
        onOpenChat={(userId, userName) => {
          const matchedUser = users.find((u) => u.id === userId || (u.username && u.username.toLowerCase() === userId.toLowerCase())) ||
                              friendsList.find((f: any) => f.id === userId || (f.username && f.username.toLowerCase() === userId.toLowerCase()));
          setDirectChatUser({
            id: userId,
            name: matchedUser?.name || userName || 'همکار',
            username: matchedUser?.username,
            avatar: matchedUser?.avatar,
            role: matchedUser?.role,
            status: 'online',
          });
          setIsNotificationCenterOpen(false);
        }}
        onNotificationClick={(n) => {
          api.markNotificationsRead(n.id).catch(() => {});

          const isChatOrFriend =
            n.type === 'message' ||
            n.type === 'friend' ||
            n.id.startsWith('notif_msg_') ||
            n.id.startsWith('notif_freq_') ||
            n.id.startsWith('notif_f_acc_') ||
            n.title.includes('پیام') ||
            n.title.includes('دوستی') ||
            n.title.includes('همکاری') ||
            Boolean(n.senderId) ||
            Boolean(n.fromUserId);

          if (isChatOrFriend) {
            let targetUserId = n.senderId || n.fromUserId;
            let targetUserName = n.senderName || n.fromUserName || n.userName;

            if (!targetUserId && n.title.includes('از ')) {
              const parts = n.title.split('از ')[1]?.split(' ');
              const rawName = parts ? parts[0]?.trim() : '';
              if (rawName) {
                const found = users.find((u) => (u.username && u.username.toLowerCase().includes(rawName.toLowerCase())) || (u.name && u.name.includes(rawName))) ||
                              friendsList.find((f: any) => (f.username && f.username.toLowerCase().includes(rawName.toLowerCase())) || (f.name && f.name.includes(rawName)));
                if (found) {
                  targetUserId = found.id;
                  targetUserName = found.name;
                }
              }
            }

            if (!targetUserId && n.userId && n.userId !== currentUser?.id) {
              targetUserId = n.userId;
            }

            if (targetUserId) {
              const matchedUser = users.find((u) => u.id === targetUserId || (u.username && u.username.toLowerCase() === targetUserId.toLowerCase())) ||
                                  friendsList.find((f: any) => f.id === targetUserId || (f.username && f.username.toLowerCase() === targetUserId.toLowerCase()));
              setDirectChatUser({
                id: targetUserId,
                name: matchedUser?.name || targetUserName || 'همکار',
                username: matchedUser?.username,
                avatar: matchedUser?.avatar,
                role: matchedUser?.role,
                status: 'online',
              });
              setIsNotificationCenterOpen(false);
              return;
            }
          }

          if (n.type === 'task') {
            setActiveTab('tasks');
            setIsNotificationCenterOpen(false);
            return;
          }

          setIsNotificationCenterOpen(false);
        }}
      />"""

assert old_notif_modal in content
content = content.replace(old_notif_modal, new_notif_modal, 1)

with open('src/components/MainLayout.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('MainLayout.tsx updated successfully!')
