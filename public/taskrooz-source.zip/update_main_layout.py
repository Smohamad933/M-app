with open('src/components/MainLayout.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update lucide-react imports
content = content.replace(
    "  Wifi,\n  Bot,\n  ShieldAlert,\n} from 'lucide-react';",
    "  Wifi,\n  Bot,\n  ShieldAlert,\n  Sun,\n  Moon,\n  Calendar,\n} from 'lucide-react';"
)

# 2. Add useTask destructuring
content = content.replace(
    "    interfaceMode,\n    setInterfaceMode,\n  } = useTask();",
    "    interfaceMode,\n    setInterfaceMode,\n    themeMode,\n    toggleThemeMode,\n    calendarType,\n    toggleCalendarType,\n  } = useTask();"
)

# 3. Add Theme and Calendar switcher buttons in top header
old_cogwheel = """                {/* Settings Cogwheel (hidden on small screens, in menu) */}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playPop();
                    if (isAdmin) {
                      setActiveTab('users');
                    } else {
                      setIsProfileModalOpen(true);
                    }
                  }}
                  className="w-8 sm:w-9 h-8 sm:h-9 rounded-full border border-slate-200/80 hover:bg-slate-100 items-center justify-center text-slate-600 transition-colors shadow-2xs cursor-pointer hidden sm:flex flex-shrink-0"
                  title="تنظیمات"
                >
                  <Settings className="w-4 h-4" />
                </button>"""

new_cogwheel = """                {/* Dark / Light Mode Switcher */}
                <button
                  type="button"
                  onClick={toggleThemeMode}
                  className={`w-8 sm:w-9 h-8 sm:h-9 rounded-full border flex items-center justify-center transition-all shadow-2xs cursor-pointer flex-shrink-0 ${
                    themeMode === 'dark'
                      ? 'border-amber-500/40 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20'
                      : 'border-slate-200/80 bg-white text-slate-600 hover:bg-slate-100'
                  }`}
                  title={themeMode === 'dark' ? 'تغییر به تم روشن (Light)' : 'تغییر به تم تاریک (Dark Mode)'}
                >
                  {themeMode === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
                </button>

                {/* Calendar Type Switcher (Jalali vs Gregorian) */}
                <button
                  type="button"
                  onClick={toggleCalendarType}
                  className="h-8 sm:h-9 px-2.5 rounded-full border border-slate-200/80 bg-white hover:bg-slate-100 text-slate-700 flex items-center gap-1 font-bold text-xs transition-colors shadow-2xs cursor-pointer flex-shrink-0"
                  title={calendarType === 'jalali' ? 'تقویم خورشیدی (شمسی) فعال است — کلیک برای تغییر به میلادی' : 'تقویم میلادی فعال است — کلیک برای تغییر به شمسی'}
                >
                  <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                  <span className="hidden sm:inline">{calendarType === 'jalali' ? 'تقویم شمسی' : 'تقویم میلادی'}</span>
                  <span className="sm:hidden">{calendarType === 'jalali' ? 'شمسی' : 'میلادی'}</span>
                </button>

                {/* Settings Cogwheel (hidden on small screens, in menu) */}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playPop();
                    if (isAdmin) {
                      setActiveTab('users');
                    } else {
                      setIsProfileModalOpen(true);
                    }
                  }}
                  className="w-8 sm:w-9 h-8 sm:h-9 rounded-full border border-slate-200/80 hover:bg-slate-100 items-center justify-center text-slate-600 transition-colors shadow-2xs cursor-pointer hidden sm:flex flex-shrink-0"
                  title="تنظیمات"
                >
                  <Settings className="w-4 h-4" />
                </button>"""

assert old_cogwheel in content
content = content.replace(old_cogwheel, new_cogwheel, 1)

with open('src/components/MainLayout.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('MainLayout.tsx updated with Theme & Calendar controls!')
