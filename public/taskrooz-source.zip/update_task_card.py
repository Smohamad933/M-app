with open('src/components/TaskCard.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update imports
content = content.replace(
    "import { formatPersianDate, toPersianDigits } from '../utils/persianDate';",
    "import { formatPersianDate, formatAppDate, toPersianDigits } from '../utils/persianDate';"
)

# 2. Add calendarType from useTask()
content = content.replace(
    "    togglePin,\n    addFocusMinutes,",
    "    togglePin,\n    addFocusMinutes,\n    calendarType,"
)

# 3. Update checkbox to show RED CHECKMARK when reasonUncompleted
old_checkbox = """        {/* Checkbox */}
        <button
          onClick={() => toggleTaskComplete(task.id)}
          aria-label={task.completed ? 'علامت‌گذاری به عنوان انجام نشده' : 'علامت‌گذاری به عنوان انجام شده'}
          className={`mt-0.5 flex-shrink-0 w-5 h-5 rounded-lg flex items-center justify-center transition-all duration-200 cursor-pointer ${
            task.completed
              ? 'bg-[#00b884] text-white shadow-xs'
              : 'border-2 border-slate-300 hover:border-[#00b884] bg-white'
          }`}
        >
          {task.completed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
        </button>"""

new_checkbox = """        {/* Checkbox - Shows Green Check when completed, Red Check when marked uncompleted with reason */}
        <button
          onClick={() => toggleTaskComplete(task.id)}
          aria-label={
            task.completed
              ? 'علامت‌گذاری به عنوان انجام نشده'
              : task.reasonUncompleted
              ? ('ثبت شده به عنوان انجام‌نشده: ' + task.reasonUncompleted)
              : 'علامت‌گذاری به عنوان انجام شده'
          }
          className={`mt-0.5 flex-shrink-0 w-5 h-5 rounded-lg flex items-center justify-center transition-all duration-200 cursor-pointer ${
            task.completed
              ? 'bg-[#00b884] text-white shadow-xs'
              : task.reasonUncompleted
              ? 'bg-rose-500 border-2 border-rose-600 text-white shadow-xs ring-2 ring-rose-200'
              : 'border-2 border-slate-300 hover:border-[#00b884] bg-white'
          }`}
          title={task.reasonUncompleted ? ('تیک قرمز: عدم انجام به دلیل «' + task.reasonUncompleted + '»') : undefined}
        >
          {task.completed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
          {!task.completed && task.reasonUncompleted && (
            <Check className="w-3.5 h-3.5 stroke-[3] text-white" />
          )}
        </button>"""

assert old_checkbox in content
content = content.replace(old_checkbox, new_checkbox, 1)

# 4. Make title click open edit modal and add explicit Edit3 icon
old_title_area = """        {/* Task Title & Description */}
        <div
          className="flex-1 min-w-0 cursor-pointer"
          onClick={() => setExpanded(!expanded)}
        >"""

new_title_area = """        {/* Task Title & Description - Clicking opens Edit Modal */}
        <div
          className="flex-1 min-w-0 cursor-pointer"
          onClick={() => openEditModal(task)}
          title="کلیک برای ویرایش مشخصات تسک"
        >"""

assert old_title_area in content
content = content.replace(old_title_area, new_title_area, 1)

# 5. Add direct Edit icon next to Pin icon
old_pin = """        {/* Pin button */}
        <button
          onClick={() => togglePin(task.id)}"""

new_pin = """        {/* Direct Edit Button */}
        <button
          onClick={() => openEditModal(task)}
          className="p-1 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-slate-100 transition-colors cursor-pointer"
          title="ویرایش مشخصات تسک"
        >
          <Edit3 className="w-3.5 h-3.5" />
        </button>

        {/* Pin button */}
        <button
          onClick={() => togglePin(task.id)}"""

assert old_pin in content
content = content.replace(old_pin, new_pin, 1)

# 6. Update reason badge to prominent red/rose style with remove button
old_reason_badge = """          {/* Reason uncompleted badge */}
          {task.reasonUncompleted && (
            <span
              className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200"
              title={`دلیل عدم انجام: ${task.reasonUncompleted}`}
            >
              <AlertTriangle className="w-3 h-3 text-amber-500" />
              عدم انجام: {task.reasonUncompleted}
            </span>
          )}"""

new_reason_badge = """          {/* Reason uncompleted badge with RED check indicator */}
          {task.reasonUncompleted && (
            <div
              className="inline-flex items-center gap-1.5 text-[10px] font-black px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-300 shadow-2xs"
              title={'دلیل عدم انجام: ' + task.reasonUncompleted}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
              <span>عدم انجام: {task.reasonUncompleted}</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  updateTask({
                    ...task,
                    reasonUncompleted: undefined,
                    uncompletedCategory: undefined,
                  });
                }}
                className="hover:text-rose-950 font-black px-1"
                title="پاک کردن دلیل عدم انجام"
              >
                ✕
              </button>
            </div>
          )}"""

assert old_reason_badge in content
content = content.replace(old_reason_badge, new_reason_badge, 1)

# 7. Update date display to respect calendarType
content = content.replace(
    "{formatPersianDate(task.date, 'dayMonth')}",
    "{formatAppDate(task.date, calendarType, 'dayMonth')}"
)

with open('src/components/TaskCard.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('TaskCard.tsx updated successfully!')
