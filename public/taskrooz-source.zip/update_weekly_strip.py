with open('src/components/WeeklyStrip.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace(
    "import { getDaysAround, getTodayISO, toPersianDigits, formatPersianDate } from '../utils/persianDate';",
    "import { getDaysAround, getTodayISO, toPersianDigits, formatPersianDate, formatAppDate } from '../utils/persianDate';"
)

content = content.replace(
    "  const { selectedDate, setSelectedDate, tasks } = useTask();",
    "  const { selectedDate, setSelectedDate, tasks, calendarType } = useTask();"
)

content = content.replace(
    "<span>{formatPersianDate(selectedDate, 'monthYear')}</span>",
    "<span>{formatAppDate(selectedDate, calendarType, 'monthYear')}</span>"
)

content = content.replace(
    "({formatPersianDate(selectedDate, 'weekday')})",
    "({formatAppDate(selectedDate, calendarType, 'weekday')})"
)

content = content.replace(
    "{day.weekdayShort}",
    "{calendarType === 'gregorian' ? day.date.toLocaleDateString('en-US', { weekday: 'short' }) : day.weekdayShort}"
)

content = content.replace(
    "{toPersianDigits(day.jalaliDay)}",
    "{calendarType === 'gregorian' ? day.date.getDate() : toPersianDigits(day.jalaliDay)}"
)

with open('src/components/WeeklyStrip.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('WeeklyStrip updated successfully!')
