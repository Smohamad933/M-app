# 1. Fix InstagramSlidesStudio.tsx
with open('src/components/InstagramSlidesStudio.tsx', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace(
    "  Download,\n  X,\n",
    "  Download,\n  X,\n  Smartphone,\n"
)

with open('src/components/InstagramSlidesStudio.tsx', 'w', encoding='utf-8') as f:
    f.write(text)

# 2. Fix AppTutorialStudio.tsx
with open('src/components/AppTutorialStudio.tsx', 'r', encoding='utf-8') as f:
    t_text = f.read()

unused_imports = [
    "  CheckCircle2,\n",
    "  Clock,\n",
    "  Calendar,\n",
    "  ShieldCheck,\n",
    "  Flame,\n",
    "  Zap,\n",
    "  Target,\n",
    "  Camera,\n",
    "  Eye,\n",
]

for imp in unused_imports:
    t_text = t_text.replace(imp, "")

t_text = t_text.replace("const { globalSettings } = useTask();", "")
t_text = t_text.replace("slides.map((s, idx) => (", "slides.map((_s, idx) => (")
t_text = t_text.replace("{renderSlideGraphic(s, format === 'story_highlight')}", "{renderSlideGraphic(_s, format === 'story_highlight')}")

with open('src/components/AppTutorialStudio.tsx', 'w', encoding='utf-8') as f:
    f.write(t_text)

print("AppTutorialStudio TypeScript fixes applied!")
