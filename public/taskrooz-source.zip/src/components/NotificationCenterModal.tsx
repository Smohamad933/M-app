import React, { useState } from 'react';
import { toPersianDigits } from '../utils/persianDate';
import {
  Bell,
  Check,
  CheckSquare,
  Users,
  Megaphone,
  MessageSquare,
  X,
} from 'lucide-react';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'task' | 'friend' | 'broadcast' | 'info' | 'message';
  timestamp: string;
  read: boolean;
  taskId?: string;
  userId?: string;
  userName?: string;
  senderId?: string;
  senderName?: string;
  fromUserId?: string;
  fromUserName?: string;
  requestId?: string;
}

interface NotificationCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications?: AppNotification[];
  onMarkAllAsRead?: () => void;
  onClearAll?: () => void;
  onNotificationClick?: (n: AppNotification) => void;
  onOpenTask?: (taskId: string) => void;
  onOpenChat?: (userId: string, userName: string) => void;
}

const DEFAULT_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-welcome',
    title: 'خوش‌آمدید به بگ تایم 👋',
    message: 'سامانه مدیریت تسک، تایم‌لاین ساعتی و تمرکز آماده استفاده است. اولین تسک خود را ثبت کنید!',
    type: 'info',
    timestamp: 'الان',
    read: false,
  },
];

export const NotificationCenterModal: React.FC<NotificationCenterModalProps> = ({
  isOpen,
  onClose,
  notifications: externalNotifications,
  onMarkAllAsRead: externalMarkAllAsRead,
  onClearAll: externalClearAll,
  onNotificationClick,
  onOpenTask,
  onOpenChat,
}) => {
  const [internalList, setInternalList] = useState<AppNotification[]>(() => {
    try {
      const saved = localStorage.getItem('taskrooz_notifications');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_NOTIFICATIONS;
  });

  if (!isOpen) return null;

  const currentList = externalNotifications || internalList;
  const unreadCount = currentList.filter((n) => !n.read).length;

  const handleMarkAllRead = () => {
    if (externalMarkAllAsRead) {
      externalMarkAllAsRead();
    } else {
      const updated = internalList.map((n) => ({ ...n, read: true }));
      setInternalList(updated);
      try {
        localStorage.setItem('taskrooz_notifications', JSON.stringify(updated));
      } catch {}
    }
  };

  const handleClearAll = () => {
    if (externalClearAll) {
      externalClearAll();
    } else {
      setInternalList([]);
      try {
        localStorage.setItem('taskrooz_notifications', JSON.stringify([]));
      } catch {}
    }
  };

  const handleClickItem = (n: AppNotification) => {
    // Mark as read internally
    if (!n.read) {
      const updated = internalList.map((item) => (item.id === n.id ? { ...item, read: true } : item));
      setInternalList(updated);
      try {
        localStorage.setItem('taskrooz_notifications', JSON.stringify(updated));
      } catch {}
    }

    if (onNotificationClick) {
      onNotificationClick(n);
      return;
    }

    const isChatOrFriend =
      n.type === 'message' ||
      n.type === 'friend' ||
      n.id.startsWith('notif_msg_') ||
      n.id.startsWith('notif_freq_') ||
      n.id.startsWith('notif_f_acc_') ||
      n.title.includes('پیام') ||
      n.title.includes('دوستی') ||
      n.title.includes('همکاری') ||
      Boolean(n.senderId) ||
      Boolean(n.fromUserId);

    if (isChatOrFriend && onOpenChat) {
      const targetUserId = n.senderId || n.fromUserId || n.userId;
      const targetUserName = n.senderName || n.fromUserName || n.userName || 'همکار';
      if (targetUserId) {
        onOpenChat(targetUserId, targetUserName);
        onClose();
        return;
      }
    }

    if (n.type === 'task' && onOpenTask) {
      onOpenTask(n.taskId || '');
      onClose();
      return;
    }

    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-end sm:p-6 p-3 pt-16 bg-slate-900/40 backdrop-blur-xs animate-in fade-in cursor-pointer"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-[28px] shadow-2xl border border-slate-200/90 dark:border-slate-800 overflow-hidden flex flex-col max-h-[85vh] animate-in slide-in-from-top-4 duration-200 cursor-default"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 px-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-800/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#121212] text-white flex items-center justify-center">
              <Bell className="w-4 h-4 text-[#00b884]" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900 dark:text-white">
                مرکز اعلان‌ها
              </h3>
              <span className="text-[10px] text-slate-400 font-bold">
                {toPersianDigits(unreadCount)} پیام خوانده‌نشده
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={handleMarkAllRead}
                className="text-[11px] font-bold text-slate-500 hover:text-black dark:text-slate-400 dark:hover:text-white px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                title="علامت خوانده شده برای همه"
              >
                خواندن همه
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 hover:text-slate-800 dark:hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notifications list */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2 divide-y divide-slate-100 dark:divide-slate-800">
          {currentList.map((n) => {
            let Icon = CheckSquare;
            let iconColor = 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 dark:text-indigo-400';
            const isMsg = n.type === 'message' || n.id.startsWith('notif_msg_') || n.title.includes('پیام');
            const isFriend = n.type === 'friend' || n.id.startsWith('notif_freq_') || n.id.startsWith('notif_f_acc_') || n.title.includes('دوستی') || n.title.includes('همکاری');
            if (isMsg) {
              Icon = MessageSquare;
              iconColor = 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 dark:text-indigo-400';
            } else if (isFriend) {
              Icon = Users;
              iconColor = 'text-[#00895f] bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-400';
            } else if (n.type === 'broadcast') {
              Icon = Megaphone;
              iconColor = 'text-amber-600 bg-amber-50 dark:bg-amber-950/40 dark:text-amber-400';
            }

            return (
              <div
                key={n.id}
                onClick={() => handleClickItem(n)}
                className={`p-3 rounded-2xl transition-all cursor-pointer flex items-start gap-3 pt-3 ${
                  !n.read
                    ? 'bg-slate-50/90 dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700/60 shadow-2xs'
                    : 'hover:bg-slate-50/60 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${iconColor}`}>
                  <Icon className="w-4 h-4" />
                </div>

                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="font-black text-xs text-slate-900 dark:text-white truncate">
                      {n.title}
                    </h4>
                    <span className="text-[10px] text-slate-400 font-mono font-bold flex-shrink-0">
                      {n.timestamp.includes('T') ? n.timestamp.split('T')[0] : n.timestamp}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug line-clamp-2">
                    {n.message}
                  </p>
                </div>

                {!n.read && (
                  <span className="w-2 h-2 rounded-full bg-[#f95738] flex-shrink-0 mt-1.5" />
                )}
              </div>
            );
          })}

          {currentList.length === 0 && (
            <div className="p-8 text-center text-slate-400 space-y-2">
              <Check className="w-8 h-8 text-[#00b884] mx-auto" />
              <p className="text-xs font-bold">اعلان جدیدی وجود ندارد.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        {currentList.length > 0 && (
          <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex justify-center">
            <button
              type="button"
              onClick={handleClearAll}
              className="text-xs font-bold text-slate-500 hover:text-rose-600 transition-colors cursor-pointer"
            >
              پاک کردن تاریخچه اعلان‌ها
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
