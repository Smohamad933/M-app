# 1. Fix Header.tsx
with open('src/components/Header.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace(", interfaceMode, toggleInterfaceMode", "")
with open('src/components/Header.tsx', 'w', encoding='utf-8') as f:
    f.write(text)

# 2. Fix ProfileModal.tsx
with open('src/components/ProfileModal.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
old_prof_hook = "const { currentUser, updateMyProfile, isPro, setIsUpgradeModalOpen, deleteMyAccount, globalSettings, interfaceMode, setInterfaceMode } = useTask();"
new_prof_hook = "const { currentUser, updateMyProfile, isPro, setIsUpgradeModalOpen, deleteMyAccount, globalSettings, interfaceMode, setInterfaceMode, themeMode, setThemeMode, calendarType, setCalendarType } = useTask();"
assert old_prof_hook in text
text = text.replace(old_prof_hook, new_prof_hook, 1)
with open('src/components/ProfileModal.tsx', 'w', encoding='utf-8') as f:
    f.write(text)

# 3. Fix UserManagementView.tsx
with open('src/components/UserManagementView.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace(
    "  Database,\n} from 'lucide-react';",
    "  Database,\n  Sun,\n  Moon,\n} from 'lucide-react';"
)
with open('src/components/UserManagementView.tsx', 'w', encoding='utf-8') as f:
    f.write(text)

# 4. Fix TaskCard.tsx
with open('src/components/TaskCard.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace(
    "import { toPersianDigits, formatPersianDate } from '../utils/persianDate';",
    "import { toPersianDigits, formatAppDate } from '../utils/persianDate';"
)
old_card_hook = """    currentUser,
    openIncompleteModal,
  } = useTask();"""
new_card_hook = """    currentUser,
    openIncompleteModal,
    calendarType,
    updateTask,
  } = useTask();"""
assert old_card_hook in text
text = text.replace(old_card_hook, new_card_hook, 1)
with open('src/components/TaskCard.tsx', 'w', encoding='utf-8') as f:
    f.write(text)

# 5. Fix TaskModal.tsx
with open('src/components/TaskModal.tsx', 'r', encoding='utf-8') as f:
    text = f.read()
text = text.replace("  formatPersianDate,\n", "  formatAppDate,\n")
with open('src/components/TaskModal.tsx', 'w', encoding='utf-8') as f:
    f.write(text)

print("Clean fixes applied!")
