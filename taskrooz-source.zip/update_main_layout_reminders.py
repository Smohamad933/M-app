with open('src/components/MainLayout.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Import RemindersModal
content = content.replace(
    "import { NotificationCenterModal, type AppNotification } from './NotificationCenterModal';",
    "import { NotificationCenterModal, type AppNotification } from './NotificationCenterModal';\nimport { RemindersModal } from './RemindersModal';"
)

# 2. useTask hook destructuring
hook_old = "    calendarType,\n    toggleCalendarType,\n  } = useTask();"
hook_new = """    calendarType,\n    toggleCalendarType,\n    reminders,\n    isRemindersModalOpen,\n    setIsRemindersModalOpen,\n  } = useTask();"""

assert hook_old in content
content = content.replace(hook_old, hook_new, 1)

# 3. Add Reminders Button in Desktop Top Header next to Notification Bell
bell_btn = """                {/* Notification Bell with interactive Modal */}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playPop();
                    setIsNotificationCenterOpen(true);
                    setUnreadNotifCount(0);
                  }}"""

rem_btn = """                {/* Reminders Button (desktop/tablet) */}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playPop();
                    setIsRemindersModalOpen(true);
                  }}
                  className="w-8 sm:w-9 h-8 sm:h-9 rounded-full border border-amber-200/80 bg-amber-50/60 hover:bg-amber-100 flex items-center justify-center text-amber-700 transition-colors shadow-2xs relative cursor-pointer flex-shrink-0 hidden sm:flex"
                  title="سیستم یادآورها و آلارم‌های ۳۰ روزه"
                >
                  <Bell className="w-4 h-4 text-amber-600" />
                  {reminders.filter((r) => r.active).length > 0 && (
                    <span className="w-2 h-2 rounded-full bg-amber-500 absolute top-1 right-1 ring-2 ring-white" />
                  )}
                </button>

                {/* Notification Bell with interactive Modal */}
                <button
                  type="button"
                  onClick={() => {
                    sounds.playPop();
                    setIsNotificationCenterOpen(true);
                    setUnreadNotifCount(0);
                  }}"""

assert bell_btn in content
content = content.replace(bell_btn, rem_btn, 1)

# 4. Add Reminders in Mobile Drawer
drawer_target = """              {/* Theme & Calendar Quick Switcher in Mobile Drawer */}"""
drawer_rem = """              {/* Reminders Button in Mobile Drawer */}
              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  sounds.playPop();
                  setIsRemindersModalOpen(true);
                }}
                className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-amber-800 bg-amber-50/80 border border-amber-200/80 font-bold text-xs transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-amber-600" />
                  <span>یادآورها (آلارم روزانه ۱ ماهه)</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-200/70 text-amber-900 font-black">
                  {toPersianDigits(reminders.filter((r) => r.active).length)} فعال
                </span>
              </button>

              {/* Theme & Calendar Quick Switcher in Mobile Drawer */}"""

assert drawer_target in content
content = content.replace(drawer_target, drawer_rem, 1)

# 5. Add RemindersModal to global modals
modal_target = "      {/* Notification Center Modal */}"
modal_add = """      {/* Reminders Modal (30-day daily alert system) */}
      <RemindersModal
        isOpen={isRemindersModalOpen}
        onClose={() => setIsRemindersModalOpen(false)}
      />

      {/* Notification Center Modal */}"""

assert modal_target in content
content = content.replace(modal_target, modal_add, 1)

with open('src/components/MainLayout.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('MainLayout.tsx updated with RemindersModal!')
