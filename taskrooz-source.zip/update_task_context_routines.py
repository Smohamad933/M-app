with open('src/context/TaskContext.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add imports of ReminderItem if not present
if 'ReminderItem,' not in content:
    content = content.replace(
        "import type {\n  Task,\n  TaskCreateInput,",
        "import type {\n  Task,\n  TaskCreateInput,\n  ReminderItem,"
    )

# 2. Add to TaskContextType interface
context_type_target = "  // Task management\n  addTask: (task: TaskCreateInput) => Promise<Task>;"
context_type_replacement = """  // Reminders management
  reminders: ReminderItem[];
  addReminder: (input: { title: string; time: string; duration: 'month' | 'week' | 'always' | 'once'; description?: string }) => Promise<void>;
  toggleReminder: (id: string) => void;
  deleteReminder: (id: string) => void;
  isRemindersModalOpen: boolean;
  setIsRemindersModalOpen: (open: boolean) => void;

  // Task management
  addTask: (task: TaskCreateInput, routineType?: 'none' | 'week' | 'month' | 'workdays') => Promise<Task>;"""

if context_type_target in content:
    content = content.replace(context_type_target, context_type_replacement, 1)

# 3. Add state & handlers inside TaskProvider
state_target = "  const [activeTab, setActiveTab] = useState<TabType>('dashboard');"
state_replacement = """  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [isRemindersModalOpen, setIsRemindersModalOpen] = useState(false);
  const [reminders, setReminders] = useState<ReminderItem[]>(() => {
    try {
      const saved = localStorage.getItem('bagtime_reminders');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'rem_default_1',
        userId: 'usr_admin_mohusyn',
        title: 'نوشیدن آب و پیاده‌روی کوتاه 💧',
        time: '11:00',
        duration: 'month',
        startDate: new Date().toISOString().slice(0, 10),
        active: true,
        createdAt: new Date().toISOString(),
      },
      {
        id: 'rem_default_2',
        userId: 'usr_admin_mohusyn',
        title: 'بررسی تسک‌ها و ثبت روتین‌های روز 📝',
        time: '17:30',
        duration: 'month',
        startDate: new Date().toISOString().slice(0, 10),
        active: true,
        createdAt: new Date().toISOString(),
      }
    ];
  });

  const addReminder = async (input: { title: string; time: string; duration: 'month' | 'week' | 'always' | 'once'; description?: string }) => {
    const today = new Date();
    const startDate = today.toISOString().slice(0, 10);
    const end = new Date(today);
    if (input.duration === 'month') {
      end.setDate(end.getDate() + 30);
    } else if (input.duration === 'week') {
      end.setDate(end.getDate() + 7);
    }
    const endDate = (input.duration === 'always' || input.duration === 'once') ? undefined : end.toISOString().slice(0, 10);

    const newRem: ReminderItem = {
      id: 'rem_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      userId: currentUser?.id || 'usr_admin_mohusyn',
      title: input.title.trim(),
      time: input.time,
      duration: input.duration,
      startDate,
      endDate,
      active: true,
      createdAt: new Date().toISOString(),
    };

    setReminders((prev) => {
      const updated = [newRem, ...prev];
      try {
        localStorage.setItem('bagtime_reminders', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    sounds.playPop();
  };

  const toggleReminder = (id: string) => {
    setReminders((prev) => {
      const updated = prev.map((r) => (r.id === id ? { ...r, active: !r.active } : r));
      try {
        localStorage.setItem('bagtime_reminders', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    sounds.playPop();
  };

  const deleteReminder = (id: string) => {
    setReminders((prev) => {
      const updated = prev.filter((r) => r.id !== id);
      try {
        localStorage.setItem('bagtime_reminders', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    sounds.playPop();
  };"""

if state_target in content:
    content = content.replace(state_target, state_replacement, 1)

# 4. Periodic reminder notifier
reminder_ticker = """  // Periodic 20s Live Reminder Notifier (Fires notification every day at specified time for up to a month)
  useEffect(() => {
    if (!currentUser) return;
    const checkReminders = () => {
      const now = new Date();
      const currentHours = String(now.getHours()).padStart(2, '0');
      const currentMins = String(now.getMinutes()).padStart(2, '0');
      const nowTimeStr = `${currentHours}:${currentMins}`;
      const todayDateStr = now.toISOString().slice(0, 10);

      reminders.forEach((rem) => {
        if (!rem.active) return;
        if (rem.time !== nowTimeStr) return;
        if (rem.lastNotifiedDate === todayDateStr) return;

        // Check if within date range
        if (rem.endDate && todayDateStr > rem.endDate) return;
        if (rem.startDate && todayDateStr < rem.startDate) return;

        // Mark as notified for today
        rem.lastNotifiedDate = todayDateStr;
        try {
          localStorage.setItem('bagtime_reminders', JSON.stringify(reminders));
        } catch {}

        sounds.playWarning();

        // Add to Notification Center
        const newNotif = {
          id: 'notif_rem_' + Date.now(),
          userId: currentUser.id,
          title: `🔔 یادآور روزانه: ${rem.title}`,
          message: `ساعت ${rem.time} فرا رسید: «${rem.title}». این یادآور به مدت ۳۰ روز هر روز به شما اعلام خواهد شد.`,
          type: 'info' as const,
          timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', hour12: false }),
          read: false,
        };

        try {
          const raw = localStorage.getItem('taskrooz_notifications');
          const notifs = raw ? JSON.parse(raw) : [];
          localStorage.setItem('taskrooz_notifications', JSON.stringify([newNotif, ...notifs]));
        } catch {}

        if ('Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification(`🔔 یادآور: ${rem.title}`, {
              body: `ساعت ${rem.time} — بگ تایم`,
              icon: '/icon-192.png',
            });
          } catch {}
        }
      });
    };

    const interval = setInterval(checkReminders, 20000);
    return () => clearInterval(interval);
  }, [currentUser, reminders]);
"""

if '  // Refresh active room data' in content and 'Periodic 20s Live Reminder Notifier' not in content:
    content = content.replace("  // Refresh active room data", reminder_ticker + "\n  // Refresh active room data", 1)

# 5. Overhaul addTask to support recurring routines (week, month, workdays)
old_add_task = """  const addTask = async (taskData: TaskCreateInput): Promise<Task> => {
    if (!isPro) {
      const activeTasksCount = tasks.filter((t) => t.userId === currentUser?.id && !t.completed).length;
      if (activeTasksCount >= 5) {
        setIsUpgradeModalOpen(true);
        sounds.playPop();
        throw new Error('سقف تسک‌های فعال در پلن رایگان ۵ عدد است. لطفاً جهت ثبت تسک‌های بیشتر، حساب خود را به نسخه ویژه (Pro) ارتقا دهید.');
      }
    }
    const created = await api.createTask({
      ...taskData,
      userId: taskData.userId || currentUser?.id || 'usr_admin_1',
    });
    setTasks((prev) => [created, ...prev]);
    sounds.playPop();
    broadcastSync('TASK_CREATED', { taskId: created.id, projectId: created.projectId });
    refreshUsers();
    refreshProjects();
    return created;
  };"""

new_add_task = """  const addTask = async (taskData: TaskCreateInput, routineType?: 'none' | 'week' | 'month' | 'workdays'): Promise<Task> => {
    if (!isPro) {
      const activeTasksCount = tasks.filter((t) => t.userId === currentUser?.id && !t.completed).length;
      if (activeTasksCount >= 5) {
        setIsUpgradeModalOpen(true);
        sounds.playPop();
        throw new Error('سقف تسک‌های فعال در پلن رایگان ۵ عدد است. لطفاً جهت ثبت تسک‌های بیشتر، حساب خود را به نسخه ویژه (Pro) ارتقا دهید.');
      }
    }

    const isRoutine = Boolean(routineType && routineType !== 'none');
    const primaryTaskInput = {
      ...taskData,
      isRoutine,
      routineType: routineType || 'none',
      userId: taskData.userId || currentUser?.id || 'usr_admin_1',
    };

    const created = await api.createTask(primaryTaskInput);
    setTasks((prev) => [created, ...prev]);
    sounds.playPop();
    broadcastSync('TASK_CREATED', { taskId: created.id, projectId: created.projectId });

    // If routine is selected (for week or month or workdays), automatically create corresponding recurring instances!
    if (isRoutine && taskData.date) {
      const baseDate = new Date(taskData.date);
      const totalDays = routineType === 'week' ? 7 : 30;
      const extraTasksToCreate: TaskCreateInput[] = [];

      for (let i = 1; i < totalDays; i++) {
        const nextDate = new Date(baseDate);
        nextDate.setDate(nextDate.getDate() + i);

        // If workdays (Saturday to Wednesday in Iran): skip Friday (day 5)
        if (routineType === 'workdays') {
          if (nextDate.getDay() === 5) continue;
        }

        const dateStr = nextDate.toISOString().slice(0, 10);
        extraTasksToCreate.push({
          ...taskData,
          date: dateStr,
          isRoutine: true,
          routineType,
          userId: taskData.userId || currentUser?.id || 'usr_admin_1',
        });
      }

      // Create recurring routine instances asynchronously
      (async () => {
        const batchCreated: Task[] = [];
        for (const item of extraTasksToCreate) {
          try {
            const extra = await api.createTask(item);
            batchCreated.push(extra);
          } catch {}
        }
        if (batchCreated.length > 0) {
          setTasks((prev) => [...batchCreated, ...prev]);
        }
      })();
    }

    refreshUsers();
    refreshProjects();
    return created;
  };"""

if old_add_task in content:
    content = content.replace(old_add_task, new_add_task, 1)

# 6. Expose in value bundle
val_target = "      addTask,\n      updateTask,"
val_replacement = """      reminders,
      addReminder,
      toggleReminder,
      deleteReminder,
      isRemindersModalOpen,
      setIsRemindersModalOpen,
      addTask,
      updateTask,"""

if val_target in content:
    content = content.replace(val_target, val_replacement, 1)

with open('src/context/TaskContext.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('TaskContext.tsx updated with reminders and routine tasks!')
