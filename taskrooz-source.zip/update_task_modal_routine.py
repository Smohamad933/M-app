with open('src/components/TaskModal.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Add Repeat to lucide-react imports
if 'Repeat,' not in content:
    content = content.replace(
        "  Sparkles,\n} from 'lucide-react';",
        "  Sparkles,\n  Repeat,\n} from 'lucide-react';"
    )

# 2. Add routineRepeat state
state_search = "  const [assignedUserId, setAssignedUserId] = useState<string>(currentUser?.id || '');"
state_add = """  const [assignedUserId, setAssignedUserId] = useState<string>(currentUser?.id || '');
  const [routineRepeat, setRoutineRepeat] = useState<'none' | 'week' | 'month' | 'workdays'>('none');"""

if 'const [routineRepeat, setRoutineRepeat]' not in content:
    content = content.replace(state_search, state_add, 1)

# 3. Reset routineRepeat on open
reset_search = "    } else {\n      setTitle('');"
reset_add = "    } else {\n      setRoutineRepeat('none');\n      setTitle('');"
if "setRoutineRepeat('none');" not in content:
    content = content.replace(reset_search, reset_add, 1)

# 4. Pass routineRepeat to addTask
add_task_old = """      } else {
        await addTask({
          title: title.trim(),
          description: description.trim() || undefined,
          date,
          time: time || undefined,
          priority,
          categoryId,
          projectId: projectId || undefined,
          completed: false,
          isPinned,
          subtasks,
          ...(currentUser?.role === 'admin' ? { userId: assignedUserId } : {}),
        });
      }"""

add_task_new = """      } else {
        await addTask({
          title: title.trim(),
          description: description.trim() || undefined,
          date,
          time: time || undefined,
          priority,
          categoryId,
          projectId: projectId || undefined,
          completed: false,
          isPinned,
          subtasks,
          isRoutine: routineRepeat !== 'none',
          routineType: routineRepeat,
          ...(currentUser?.role === 'admin' ? { userId: assignedUserId } : {}),
        }, routineRepeat);
      }"""

if add_task_old in content:
    content = content.replace(add_task_old, add_task_new, 1)

# 5. Add UI selector for recurring routine (only when creating new task)
routine_ui = """          {/* Recurring Routine Selector (تکرار خودکار برای تمام هفته یا تمام ماه) */}
          {!editingTask && (
            <div className="space-y-2 p-3.5 rounded-2xl bg-[#f8fafc] border border-slate-200">
              <div className="flex items-center justify-between">
                <label className="font-extrabold text-slate-700 flex items-center gap-1.5 text-xs">
                  <Repeat className="w-3.5 h-3.5 text-indigo-600" />
                  <span>تکرار به عنوان روتین روزانه</span>
                </label>
                {routineRepeat !== 'none' && (
                  <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-200">
                    فعال شد
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                با یک‌بار ثبت، این تسک به‌صورت خودکار در تمام روزهای آینده تکرار می‌شود و نیازی به وارد کردن دستی روزانه نیست:
              </p>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'none', label: 'فقط همین روز', desc: 'تک‌روز / بدون تکرار' },
                  { id: 'week', label: '🔁 تمام این هفته', desc: '۷ روز متوالی' },
                  { id: 'month', label: '📅 تمام این ماه', desc: '۳۰ روز متوالی' },
                  { id: 'workdays', label: '💼 روزهای کاری', desc: 'شنبه تا چهارشنبه' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setRoutineRepeat(item.id as any)}
                    className={`p-2.5 rounded-xl border text-right transition-all cursor-pointer flex flex-col gap-0.5 ${
                      routineRepeat === item.id
                        ? 'bg-indigo-50 border-indigo-500 text-indigo-900 shadow-xs font-black'
                        : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <span className="font-extrabold text-xs">{item.label}</span>
                    <span className="text-[10px] text-slate-400 font-bold">{item.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Priority */}"""

if '{/* Priority */}' in content and 'Recurring Routine Selector' not in content:
    content = content.replace('{/* Priority */}', routine_ui, 1)

with open('src/components/TaskModal.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('TaskModal.tsx updated!')
