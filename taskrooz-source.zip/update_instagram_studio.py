with open('src/components/InstagramSlidesStudio.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Clean up STORY_CALENDAR_DAYS: remove internal notes like "(قلاب و تعامل)"
content = content.replace("time: '۱۰:۰۰ صبح (قلاب و تعامل)',", "time: 'صبح بخیر ☀️',")
content = content.replace("time: '۱۴:۰۰ ظهر (آموزش و نمایش زنده ویژگی)',", "time: 'آموزش روز ⚡',")
content = content.replace("time: '۱۹:۰۰ عصر (نتیجه عملی و دعوت به دایرکت)',", "time: 'نکته پایانی 💡',")

content = content.replace("sticker: 'استیکر نظرسنجی (بله/خیر) یا اسلایدر آتش',", "sticker: 'روی نظرسنجی بالا بزنید 👆',")
content = content.replace("sticker: 'اسکرین‌شات سامانه بَگ‌تایم + گیف اشاره‌گر',", "sticker: 'پیش‌نمایش زنده در وب‌اپلیکیشن و افزونه',")
content = content.replace("sticker: 'باکس سوال (Question Box) یا دایرکت پیج',", "sticker: 'ارسال کلمه «بگ‌تایم» در دایرکت 📩',")

# Fix BiDi brackets for Time Blocking in story1 body
content = content.replace(
    "اگر حس می‌کنی سردرگمی، امروز قراره تکنیک «${cycle.name}» رو با هم باز کنیم.",
    "اگر احساس سردرگمی داری، امروز قراره تکنیک «برنامه‌ریزی و دیلی‌پلنر ساعتی» رو با هم باز کنیم."
)

# 2. Add showStoryBadge and showStoryActionBox state (default false to completely remove from story as requested)
old_state = """  const [storyTheme, setStoryTheme] = useState<StoryTheme>('dark');
  const [showStoryFooter, setShowStoryFooter] = useState<boolean>(false);"""

new_state = """  const [storyTheme, setStoryTheme] = useState<StoryTheme>('dark');
  const [showStoryBadge, setShowStoryBadge] = useState<boolean>(false);
  const [customStoryBadgeText, setCustomStoryBadgeText] = useState<string>('');
  const [showStoryActionBox, setShowStoryActionBox] = useState<boolean>(false);
  const [showStoryFooter, setShowStoryFooter] = useState<boolean>(false);"""

assert old_state in content
content = content.replace(old_state, new_state, 1)

# Default exportQuality to 'hd' (1080p) which is native Instagram resolution
content = content.replace(
    "const [exportQuality, setExportQuality] = useState<'4k' | 'hd'>('4k');",
    "const [exportQuality, setExportQuality] = useState<'4k' | 'hd'>('hd');"
)

# 3. Update renderStoryContent to conditionally render top badge and bottom sticker box
old_badge_render = """        {/* Center Body */}
        <div className="my-auto space-y-2.5 z-10 text-right py-2 flex-1 flex flex-col justify-center">
          <div className={`inline-block px-2.5 py-1 rounded-xl font-black text-xs self-start ${theme.badge}`}>
            {slotData.time}
          </div>

          <h2 className="text-base font-black leading-snug">
            {hookOrTitle}
          </h2>"""

new_badge_render = """        {/* Center Body */}
        <div className="my-auto space-y-2.5 z-10 text-right py-2 flex-1 flex flex-col justify-center">
          {showStoryBadge && (
            <div className={`inline-block px-2.5 py-1 rounded-xl font-black text-xs self-start ${theme.badge}`}>
              {customStoryBadgeText || slotData.time}
            </div>
          )}

          <h2 className="text-base font-black leading-snug">
            {hookOrTitle}
          </h2>"""

assert old_badge_render in content
content = content.replace(old_badge_render, new_badge_render, 1)

old_sticker_render = """          <div className={`p-3 rounded-2xl border text-xs font-bold leading-relaxed whitespace-pre-wrap ${theme.card}`}>
            {bodyText}
          </div>

          <div className="p-2.5 rounded-xl border bg-emerald-500/15 border-emerald-500/30 text-emerald-600 dark:text-emerald-300 text-xs font-bold">
            {stickerOrNote}
          </div>"""

new_sticker_render = """          <div className={`p-3 rounded-2xl border text-xs font-bold leading-relaxed whitespace-pre-wrap ${theme.card}`}>
            {bodyText}
          </div>

          {showStoryActionBox && (
            <div className="p-2.5 rounded-xl border bg-emerald-500/15 border-emerald-500/30 text-emerald-600 dark:text-emerald-300 text-xs font-bold">
              {stickerOrNote}
            </div>
          )}"""

assert old_sticker_render in content
content = content.replace(old_sticker_render, new_sticker_render, 1)

# 4. Add toggles in Story Controls UI
target_footer_control = """              {/* Story Footer Customizer & Toggle */}"""

new_controls_ui = """              {/* Story Badge & Interaction Box Toggles */}
              <div className="p-5 rounded-3xl bg-[#0d1322] border border-slate-800 space-y-3">
                <span className="text-xs font-black text-white flex items-center gap-1.5">
                  <Sliders className="w-4 h-4 text-amber-400" />
                  <span>تنظیم نشانگر بالا و کادر پایین استوری</span>
                </span>

                <div className="space-y-2 pt-1 border-t border-slate-800/80">
                  <label className="flex items-center justify-between cursor-pointer p-2.5 rounded-2xl bg-slate-900 border border-slate-800">
                    <span className="text-xs font-bold text-slate-300">نمایش نشانگر بالای استوری (Badge)</span>
                    <input
                      type="checkbox"
                      checked={showStoryBadge}
                      onChange={(e) => setShowStoryBadge(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-500 bg-slate-800 border-slate-700 cursor-pointer"
                    />
                  </label>

                  {showStoryBadge && (
                    <div className="space-y-1 pr-2">
                      <label className="text-[11px] text-slate-400 font-bold">متن نشانگر بالای استوری:</label>
                      <input
                        type="text"
                        value={customStoryBadgeText}
                        onChange={(e) => setCustomStoryBadgeText(e.target.value)}
                        placeholder="مثال: صبح بخیر ☀️، نکته روز، بَگ‌تایم..."
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs outline-none focus:border-amber-500 font-bold"
                      />
                    </div>
                  )}

                  <label className="flex items-center justify-between cursor-pointer p-2.5 rounded-2xl bg-slate-900 border border-slate-800">
                    <span className="text-xs font-bold text-slate-300">نمایش کادر پایین استوری (استیکر / دایرکت)</span>
                    <input
                      type="checkbox"
                      checked={showStoryActionBox}
                      onChange={(e) => setShowStoryActionBox(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-500 bg-slate-800 border-slate-700 cursor-pointer"
                    />
                  </label>
                </div>
              </div>

              {/* Story Footer Customizer & Toggle */}"""

assert target_footer_control in content
content = content.replace(target_footer_control, new_controls_ui, 1)

with open('src/components/InstagramSlidesStudio.tsx', 'w', encoding='utf-8') as f:
    f.write(content)

print('InstagramSlidesStudio.tsx updated successfully!')
