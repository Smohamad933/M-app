# 1. Fix TaskContext.tsx
with open('src/context/TaskContext.tsx', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace(
    "  TaskCreateInput,\n",
    "  TaskCreateInput,\n  ReminderItem,\n"
)

text = text.replace(
    "            const extra = await api.createTask(item);",
    "            const extra = await api.createTask({\n              ...item,\n              userId: item.userId || currentUser?.id || 'usr_admin_1',\n            });"
)

with open('src/context/TaskContext.tsx', 'w', encoding='utf-8') as f:
    f.write(text)

# 2. Fix DashboardTaskList.tsx
with open('src/components/DashboardTaskList.tsx', 'r', encoding='utf-8') as f:
    d_text = f.read()

d_text = d_text.replace(", Repeat,", ",")
with open('src/components/DashboardTaskList.tsx', 'w', encoding='utf-8') as f:
    f.write(d_text)

print("TypeScript fixes applied!")
