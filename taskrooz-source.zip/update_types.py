with open('src/types/index.ts', 'r', encoding='utf-8') as f:
    content = f.read()

# Add ReminderItem interface
reminder_def = """export interface ReminderItem {
  id: string;
  userId: string;
  title: string;
  time: string; // HH:mm (e.g. "09:00")
  duration: 'month' | 'week' | 'always' | 'once'; // e.g. 'month' = daily for 1 month
  startDate: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD
  active: boolean;
  lastNotifiedDate?: string; // YYYY-MM-DD
  createdAt: string;
}

"""

if 'export interface ReminderItem' not in content:
    content = reminder_def + content

# Update Task interface with routine fields
task_old = """  reminder?: boolean;
  repeat?: 'none' | 'daily' | 'weekly';
  createdAt: string;"""

task_new = """  reminder?: boolean;
  repeat?: 'none' | 'daily' | 'weekly';
  isRoutine?: boolean;
  routineType?: 'none' | 'week' | 'month' | 'workdays';
  createdAt: string;"""

if task_old in content:
    content = content.replace(task_old, task_new, 1)

with open('src/types/index.ts', 'w', encoding='utf-8') as f:
    f.write(content)

print('types/index.ts updated!')
