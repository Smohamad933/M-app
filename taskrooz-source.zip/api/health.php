<?php
/**
 * TaskRooz - Server Health & Diagnostics (MySQL + Server Info)
 * Access at: https://bagtime.negahm.ir/api/health.php
 */
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

$isMysqlConnected = ($db->mode === 'mysql' && $pdo !== null);
$dbTables = [];
if ($isMysqlConnected) {
    try {
        $stmt = $pdo->query("SHOW TABLES");
        $dbTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {}
}

$users = $db->getAllUsers();
$rooms = $db->listFocusRooms();

echo json_encode([
    'status' => 'ok',
    'app' => 'TaskRooz (تسک‌روز)',
    'author' => 'Mohusyn (mohusyn.ir)',
    'php_version' => PHP_VERSION,
    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'database' => [
        'installed' => $db->isInstalled(),
        'engine' => $db->mode,
        'mysql_connected' => $isMysqlConnected,
        'tables_count' => count($dbTables),
    ],
    'counts' => [
        'users' => count($users),
        'rooms' => count($rooms),
        'tasks' => count($db->getTasks(null)),
    ],
    'super_admin' => [
        'username' => 'Mohusyn',
        'status' => 'active',
    ],
    'registered_usernames' => array_map(function($u) { return $u['username']; }, $users),
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
